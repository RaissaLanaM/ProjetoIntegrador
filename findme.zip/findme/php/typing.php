<?php
session_start();
header('Content-Type: application/json; charset=utf-8');

require_once __DIR__ . '/../includes/conexao.php';

/**
 * Helper para responder JSON e encerrar
 */
function jsonResponse(array $data, int $statusCode = 200): void
{
    http_response_code($statusCode);
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit;
}

// Garante usuário logado
if (empty($_SESSION['usuario_id'])) {
    jsonResponse(['ok' => false], 401);
}

$usuarioId = (int) $_SESSION['usuario_id'];

// Garante que seja POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    jsonResponse(['ok' => false], 405); // Método não permitido
}

// Coleta e valida o ID do chat
$cid = isset($_POST['chat_id']) ? (int) $_POST['chat_id'] : 0;
if ($cid <= 0) {
    jsonResponse(['ok' => false], 400);
}

try {
    /* ===========================================================
       1) Confere se o usuário realmente participa do chat
    ============================================================ */
    $sql = "
        SELECT 1
        FROM chats
        WHERE id = :cid
          AND (:uid IN (usuario1_id, usuario2_id))
        LIMIT 1
    ";

    $stmt = $conexao->prepare($sql);
    $stmt->execute([
        ':cid' => $cid,
        ':uid' => $usuarioId,
    ]);

    if (!$stmt->fetchColumn()) {
        // Usuário não faz parte desse chat
        jsonResponse(['ok' => false], 403);
    }

    /* ===========================================================
       2) Cria/atualiza o ping de digitação em arquivo temporário
    ============================================================ */
    $baseDir = rtrim(sys_get_temp_dir(), DIRECTORY_SEPARATOR);
    $file    = $baseDir . DIRECTORY_SEPARATOR . "typing_findme_{$cid}_user_{$usuarioId}.ping";

    // touch() atualiza o mtime do arquivo; se não existir, cria
    if (!touch($file)) {
        // Se não conseguir criar, não quebra o chat, só retorna false
        jsonResponse(['ok' => false], 500);
    }

    /* ===========================================================
       3) Resposta OK
    ============================================================ */
    jsonResponse(['ok' => true]);

} catch (Throwable $e) {
    // Em produção você pode logar: error_log('ERRO TYPING_PING: ' . $e->getMessage());
    jsonResponse(['ok' => false], 500);
}
