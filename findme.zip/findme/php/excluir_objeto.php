<?php
session_start();
require_once '../includes/conexao.php';

/**
 * Redireciona para o dashboard com mensagem.
 *
 * @param string $msg
 * @param string $tipo 'erro' ou 'sucesso'
 * @return void
 */
function voltarDashboard(string $msg, string $tipo = 'erro'): void
{
    if ($tipo === 'sucesso') {
        $_SESSION['mensagem_sucesso'] = $msg;
    } else {
        $_SESSION['mensagem_erro'] = $msg;
    }

    header("Location: ../html/dashboard.php");
    exit;
}

// Garante usuário logado
if (empty($_SESSION['usuario_id'])) {
    $_SESSION['mensagem_erro'] = "Você precisa estar logado.";
    header("Location: ../html/login.php");
    exit;
}

$usuarioLogado = (int) $_SESSION['usuario_id'];

// exige método POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    voltarDashboard("Requisição inválida para exclusão de objeto.");
}

/* ===========================================================
   1) Validação de CSRF
=========================================================== */
$tokenPost = $_POST['csrf']  ?? '';
$tokenSess = $_SESSION['csrf'] ?? '';

if (!$tokenPost || !$tokenSess || !hash_equals($tokenSess, $tokenPost)) {
    voltarDashboard("Token inválido. Tente novamente.");
}

// Depois de validar, pode invalidar o token
unset($_SESSION['csrf']);

/* ===========================================================
   2) Coleta e validação do ID do objeto
=========================================================== */
$id = isset($_POST['id']) ? (int) $_POST['id'] : 0;

if ($id <= 0) {
    voltarDashboard("Objeto inválido para exclusão.");
}

try {
    $conexao->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    /* ===========================================================
       3) Confere se o objeto existe e pertence ao usuário logado
    ============================================================ */
    $stmt = $conexao->prepare("
        SELECT id, id_usuario, imagem
        FROM objetos
        WHERE id = :id
        LIMIT 1
    ");
    $stmt->bindValue(':id', $id, PDO::PARAM_INT);
    $stmt->execute();
    $obj = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$obj) {
        voltarDashboard("Objeto não encontrado.");
    }

    if ((int) $obj['id_usuario'] !== $usuarioLogado) {
        voltarDashboard("Você não tem permissão para excluir este objeto.");
    }

    /* ===========================================================
       4) Inicia transação
    ============================================================ */
    $conexao->beginTransaction();

    /* ===========================================================
       5) Remove dependências (FKs) antes do objeto
    ============================================================ */

    // histórico de edição (se existir)
    $stHist = $conexao->prepare("
        DELETE FROM historico_edicao
        WHERE objeto_id = :id
    ");
    $stHist->bindValue(':id', $id, PDO::PARAM_INT);
    try { $stHist->execute(); } catch (Throwable $e) {
        // se a tabela não existir, ignora (para não quebrar TCC)
    }

    // denúncias relacionadas ao objeto
    $stDen = $conexao->prepare("
        DELETE FROM denuncias
        WHERE objeto_id = :id
    ");
    $stDen->bindValue(':id', $id, PDO::PARAM_INT);
    try { $stDen->execute(); } catch (Throwable $e) {
        // mesma ideia: ignora se não existir tabela
    }

    /* ===========================================================
       6) Remove imagem física (se houver) com verificação de path
    ============================================================ */
    if (!empty($obj['imagem'])) {
        $baseDir = realpath(__DIR__ . '/../uploads/objetos');
        $file    = realpath(__DIR__ . '/../uploads/objetos/' . $obj['imagem']);

        // Verifica se o arquivo está dentro da pasta esperada (segurança)
        if ($file && $baseDir && strpos($file, $baseDir) === 0 && is_file($file)) {
            @unlink($file);
        }
    }

    /* ===========================================================
       7) Exclui o registro do objeto em si
    ============================================================ */
    $del = $conexao->prepare("
        DELETE FROM objetos
        WHERE id = :id
        LIMIT 1
    ");
    $del->bindValue(':id', $id, PDO::PARAM_INT);
    $del->execute();

    if ($del->rowCount() < 1) {
        $conexao->rollBack();
        voltarDashboard("Não foi possível excluir o objeto.");
    }

    $conexao->commit();
    voltarDashboard("Objeto excluído com sucesso.", 'sucesso');

} catch (Throwable $e) {
    if ($conexao->inTransaction()) {
        $conexao->rollBack();
    }
    voltarDashboard("Erro ao excluir: " . $e->getMessage());
}
