<?php
session_start();
require_once '../includes/conexao.php';

$usuarioLogado = isset($_SESSION['usuario_id']) ? (int) $_SESSION['usuario_id'] : null;

// helper simples para escapar HTML
function e(string $s): string {
    return htmlspecialchars($s, ENT_QUOTES, 'UTF-8');
}

// valida id do objeto
$id_objeto = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);

if (!$id_objeto || $id_objeto <= 0) {
    $_SESSION['mensagem_erro'] = 'Objeto não encontrado.';
    header('Location: listar_objetos.php');
    exit;
}

// consulta o objeto + dono
$sql = "
    SELECT 
        o.*,
        u.nome  AS nome_usuario,
        u.email AS email_usuario
    FROM objetos o
    JOIN usuarios u ON u.id = o.id_usuario
    WHERE o.id = :id
    LIMIT 1
";

$stmt = $conexao->prepare($sql);
$stmt->bindValue(':id', $id_objeto, PDO::PARAM_INT);
$stmt->execute();
$objeto = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$objeto) {
    $_SESSION['mensagem_erro'] = 'Objeto não encontrado.';
    header('Location: listar_objetos.php');
    exit;
}

// trata imagem (se existir)
$imgName   = trim((string)($objeto['imagem'] ?? ''));
$imgWeb    = $imgName ? "../uploads/objetos/{$imgName}" : '';
$imgFsPath = $imgName ? realpath(__DIR__ . "/../uploads/objetos/{$imgName}") : false;
$temArquivo = ($imgName && $imgFsPath && is_file($imgFsPath));

// tipo/status do objeto
$tipo = strtolower((string)($objeto['tipo_objeto'] ?? ''));
switch ($tipo) {
    case 'perdido':
        $textoStatus = 'Perdido';
        $badgeClass  = 'status-perdido';
        break;
    case 'devolvido':
        $textoStatus = 'Devolvido';
        $badgeClass  = 'status-devolvido';
        break;
    case 'achado':
    default:
        $textoStatus = 'Achado';
        $badgeClass  = 'status-achado';
        break;
}

$dataFmt = $objeto['data_encontrado']
    ? date('d/m/Y', strtotime($objeto['data_encontrado']))
    : '—';

$isOwner = $usuarioLogado && ((int)$objeto['id_usuario'] === $usuarioLogado);
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Detalhes do objeto - <?= e($objeto['titulo'] ?? 'Objeto'); ?> | FindMe</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Fonte global -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;700&display=swap" rel="stylesheet">

    <!-- CSS -->
    <link rel="stylesheet" href="../assets/css/header.css">
    <link rel="stylesheet" href="../assets/css/detalhes_objeto.css">
</head>
<body>
<?php include '../includes/header.php'; ?>

<main class="detalhes-wrapper">
    <section class="detalhes-card">
        <header class="detalhes-header">
            <span class="status-chip <?= e($badgeClass); ?>">
                <?= e($textoStatus); ?>
            </span>
            <h1 class="detalhes-titulo"><?= e($objeto['titulo']); ?></h1>
            <p class="detalhes-sub">
                Cadastrado por <strong><?= e($objeto['nome_usuario']); ?></strong>
            </p>
        </header>

        <div class="detalhes-grid">
            <div class="detalhes-col imagem">
                <?php if ($temArquivo): ?>
                    <img
                        src="<?= e($imgWeb); ?>"
                        alt="Imagem do objeto: <?= e($objeto['titulo']); ?>"
                        class="detalhes-img"
                        loading="lazy"
                    >
                <?php else: ?>
                    <div class="detalhes-img placeholder" role="img" aria-label="Sem imagem disponível">
                        <span>Sem imagem</span>
                    </div>
                <?php endif; ?>
            </div>

            <div class="detalhes-col info">
                <h2>Informações do objeto</h2>

                <p><strong>Descrição:</strong><br>
                    <span><?= nl2br(e($objeto['descricao'] ?? '')); ?></span>
                </p>

                <?php if (!empty($objeto['categoria'])): ?>
                    <p><strong>Categoria:</strong> <?= e($objeto['categoria']); ?></p>
                <?php endif; ?>

                <?php if (!empty($objeto['local_encontrado'])): ?>
                    <p><strong>Local informado:</strong> <?= e($objeto['local_encontrado']); ?></p>
                <?php endif; ?>

                <p><strong>Data:</strong> <?= e($dataFmt); ?></p>

                <h3 class="detalhes-subbloco">Contato</h3>
                <p>
                    <strong>Anunciante:</strong> <?= e($objeto['nome_usuario']); ?><br>
                    <strong>E-mail:</strong>
                    <a href="mailto:<?= e($objeto['email_usuario']); ?>">
                        <?= e($objeto['email_usuario']); ?>
                    </a>
                </p>

                <div class="detalhes-acoes">
                    <?php if ($usuarioLogado): ?>
                        <?php if ($isOwner): ?>
                            <a class="btn btn-secundario" href="editar_objeto.php?id=<?= (int)$objeto['id']; ?>">
                                ✏️ Editar anúncio
                            </a>
                        <?php else: ?>
                            <a
                                class="btn btn-primario"
                                href="../php/iniciar_chat.php?id_dono=<?= (int)$objeto['id_usuario']; ?>"
                            >
                                💬 Conversar com o anunciante
                            </a>

                            <a
                                class="btn btn-outline"
                                href="denunciar_objeto.php?obj=<?= (int)$objeto['id']; ?>"
                            >
                                🚩 Denunciar anúncio
                            </a>
                        <?php endif; ?>
                    <?php else: ?>
                        <p class="detalhes-aviso-login">
                            Para conversar com o anunciante ou denunciar este anúncio,
                            <a href="login.php">faça login</a>.
                        </p>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <footer class="detalhes-footer">
            <a class="link-voltar" href="listar_objetos.php">← Voltar para a lista de objetos</a>
        </footer>
    </section>
</main>

<?php include '../includes/footer.php'; ?>
</body>
</html>
