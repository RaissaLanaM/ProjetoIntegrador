<?php
// php/notificacoes_listar.php
session_start();
header('Content-Type: application/json; charset=utf-8');

if (!isset($_SESSION['usuario_id'])) {
    echo json_encode([
        'itens'     => [],
        'nao_lidas' => 0
    ]);
    exit;
}

require_once __DIR__ . '/../includes/conexao.php';

$uid = (int) $_SESSION['usuario_id'];

try {
    // últimas 20 notificações do usuário logado
    $st = $conexao->prepare("
        SELECT 
            id,
            tipo,
            titulo,
            mensagem,
            lida,
            created_at,
            link_destino
        FROM notificacoes
        WHERE usuario_id = :uid
        ORDER BY created_at DESC
        LIMIT 20
    ");
    $st->bindValue(':uid', $uid, PDO::PARAM_INT);
    $st->execute();

    $itens = [];
    while ($row = $st->fetch(PDO::FETCH_ASSOC)) {
        $createdAt = $row['created_at'] ?? null;

        $itens[] = [
            'id'         => (int) $row['id'],
            'tipo'       => $row['tipo'] ?? '',
            'titulo'     => $row['titulo'] ?? '',
            'mensagem'   => $row['mensagem'] ?? '',
            'lida'       => ((int) ($row['lida'] ?? 0) === 1),
            'created_at' => $createdAt,
            'data_label' => $createdAt
                ? date('d/m/Y H:i', strtotime($createdAt))
                : '',
            'link'       => $row['link_destino'] ?: '#'
        ];
    }

    // contador de não lidas
    $stCount = $conexao->prepare("
        SELECT COUNT(*) 
        FROM notificacoes 
        WHERE usuario_id = :uid AND lida = 0
    ");
    $stCount->bindValue(':uid', $uid, PDO::PARAM_INT);
    $stCount->execute();
    $naoLidas = (int) $stCount->fetchColumn();

    echo json_encode([
        'itens'     => $itens,
        'nao_lidas' => $naoLidas
    ]);
} catch (Throwable $e) {
    echo json_encode([
        'itens'     => [],
        'nao_lidas' => 0,
        'erro'      => $e->getMessage()
    ]);
}
