<?php
session_start();
require_once '../includes/conexao.php';

if (!isset($_SESSION['usuario_id'])) {
    header('Location: ../html/login.php');
    exit();
}

$de   = (int) $_SESSION['usuario_id'];
$para = (int) ($_POST['para_usuario_id'] ?? 0);
$nota = (int) ($_POST['nota'] ?? 0);
$comentario = trim($_POST['comentario'] ?? '');

if ($para <= 0 || $para === $de || $nota < 1 || $nota > 5) {
    $_SESSION['mensagem_erro'] = "Avaliação inválida.";
    header("Location: ../html/perfil.php?id=" . $para);
    exit();
}

// Evita duplicar avaliação (um avaliador por avaliado)
$stmtCheck = $conexao->prepare("
    SELECT id 
    FROM avaliacoes 
    WHERE de_usuario_id = :de AND para_usuario_id = :para 
    LIMIT 1
");
$stmtCheck->execute([
    ':de'   => $de,
    ':para' => $para
]);

if ($stmtCheck->fetch()) {
    $_SESSION['mensagem_erro'] = "Você já avaliou este usuário.";
    header("Location: ../html/perfil.php?id=" . $para);
    exit();
}

// Insere avaliação
$stmt = $conexao->prepare("
    INSERT INTO avaliacoes (de_usuario_id, para_usuario_id, nota, comentario, data_avaliacao)
    VALUES (:de, :para, :nota, :comentario, NOW())
");
$stmt->execute([
    ':de'         => $de,
    ':para'       => $para,
    ':nota'       => $nota,
    ':comentario' => $comentario,
]);

// ===============================
// NOTIFICAÇÃO AUTOMÁTICA 🔔
// ===============================
try {
    // pega nome de quem avaliou (remetente)
    $nomeDe = 'Um usuário';
    $stUser = $conexao->prepare("SELECT nome FROM usuarios WHERE id = :id LIMIT 1");
    $stUser->bindValue(':id', $de, PDO::PARAM_INT);
    $stUser->execute();
    if ($rowU = $stUser->fetch(PDO::FETCH_ASSOC)) {
        $nomeDe = $rowU['nome'];
    }

    // monta preview opcional do comentário
    $previewComentario = '';
    if ($comentario !== '') {
        if (function_exists('mb_strimwidth')) {
            $previewComentario = mb_strimwidth($comentario, 0, 80, '...', 'UTF-8');
        } else {
            $previewComentario = substr($comentario, 0, 80) . (strlen($comentario) > 80 ? '...' : '');
        }
        $previewComentario = ' Comentário: "' . $previewComentario . '"';
    }

    $tituloNotif   = 'Você recebeu uma nova avaliação';
    $mensagemNotif = sprintf(
        'Você foi avaliado por %s com nota %d/5.%s',
        $nomeDe,
        $nota,
        $previewComentario
    );

    // link para o perfil do avaliado (de quem está recebendo a avaliação)
    $linkNotif = 'perfil.php?id=' . $para;

    $stNotif = $conexao->prepare("
        INSERT INTO notificacoes
            (usuario_id, tipo, titulo, mensagem, lida, created_at, link_destino)
        VALUES
            (:uid, 'avaliacao', :tit, :msg, 0, NOW(), :lnk)
    ");
    $stNotif->execute([
        ':uid' => $para,
        ':tit' => $tituloNotif,
        ':msg' => $mensagemNotif,
        ':lnk' => $linkNotif,
    ]);

} catch (Throwable $e) {
    // Não quebra o fluxo do TCC se der erro de notificação
    // error_log("ERRO NOTIF AVALIACAO: " . $e->getMessage());
}

// Redireciona de volta ao perfil do avaliado
header("Location: ../html/perfil.php?id=" . $para);
exit();
