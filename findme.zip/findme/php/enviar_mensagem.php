<?php
// php/enviar_mensagem_ajax.php
session_start();
header('Content-Type: application/json; charset=utf-8');

require_once __DIR__ . '/../includes/conexao.php';

$response = ['ok' => false];

// 1) Verifica se o usuário está logado
if (empty($_SESSION['usuario_id'])) {
    $response['error'] = 'Usuário não logado.';
    echo json_encode($response);
    exit;
}

$deId = (int) $_SESSION['usuario_id'];

// 2) Garante que seja POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    $response['error'] = 'Método inválido.';
    echo json_encode($response);
    exit;
}

// 3) Coleta e normaliza dados vindos do JS
$chatId = isset($_POST['chat_id']) ? (int) $_POST['chat_id'] : 0;
$paraId = isset($_POST['para_usuario_id']) ? (int) $_POST['para_usuario_id'] : 0;
$texto  = isset($_POST['mensagem']) ? trim($_POST['mensagem']) : '';

if ($chatId <= 0 || $paraId <= 0 || $texto === '') {
    $response['error'] = 'Dados inválidos.';
    echo json_encode($response);
    exit;
}

try {
    // Ativa exceções no PDO para facilitar debug
    $conexao->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // 4) Insere a mensagem
    $sqlInsert = "
        INSERT INTO mensagens (chat_id, de_usuario_id, para_usuario_id, mensagem, data_envio)
        VALUES (:chat_id, :de, :para, :msg, NOW())
    ";

    $stmt = $conexao->prepare($sqlInsert);
    $stmt->execute([
        ':chat_id' => $chatId,
        ':de'      => $deId,
        ':para'    => $paraId,
        ':msg'     => $texto,
    ]);

    $msgId = (int) $conexao->lastInsertId();

    // 5) Atualiza o chat com a última atividade
    $sqlUpdateChat = "
        UPDATE chats
        SET atualizado_em = CURRENT_TIMESTAMP
        WHERE id = :cid
    ";
    $up = $conexao->prepare($sqlUpdateChat);
    $up->execute([':cid' => $chatId]);

    // 6) Cria notificação automática para o destinatário
    //    (apenas se a mensagem não for para o próprio usuário, por segurança)
    if ($paraId !== $deId) {
        // Busca nome do remetente (opcional, só pra deixar a msg mais amigável)
        $nomeRemetente = 'um usuário';
        $sqlUser = "SELECT nome FROM usuarios WHERE id = :id LIMIT 1";
        $stUser = $conexao->prepare($sqlUser);
        $stUser->bindValue(':id', $deId, PDO::PARAM_INT);
        $stUser->execute();
        if ($rowUser = $stUser->fetch(PDO::FETCH_ASSOC)) {
            $nomeRemetente = $rowUser['nome'];
        }

        // Cria um pequeno preview da mensagem
        if (function_exists('mb_strimwidth')) {
            $preview = mb_strimwidth($texto, 0, 80, '...', 'UTF-8');
        } else {
            $preview = substr($texto, 0, 80) . (strlen($texto) > 80 ? '...' : '');
        }

        $tituloNotif   = 'Nova mensagem no chat';
        $mensagemNotif = "Você recebeu uma nova mensagem de {$nomeRemetente}: \"{$preview}\"";
        $linkNotif     = "chat.php?id=" . $chatId;

        $sqlNotif = "
            INSERT INTO notificacoes
                (usuario_id, tipo, titulo, mensagem, lida, created_at, link_destino)
            VALUES
                (:uid, 'chat', :titulo, :mensagem, 0, NOW(), :link)
        ";

        $stNotif = $conexao->prepare($sqlNotif);
        $stNotif->bindValue(':uid',     $paraId,           PDO::PARAM_INT);
        $stNotif->bindValue(':titulo',  $tituloNotif,      PDO::PARAM_STR);
        $stNotif->bindValue(':mensagem',$mensagemNotif,    PDO::PARAM_STR);
        $stNotif->bindValue(':link',    $linkNotif,        PDO::PARAM_STR);
        $stNotif->execute();
    }

    // 7) Monta o objeto que o JS espera em renderMsg()
    $hora     = date('H:i');
    $diaLabel = date('d/m/Y');

    $response['ok'] = true;
    $response['message'] = [
        'id'       => $msgId,
        'text'     => $texto,
        'time'     => $hora,
        'dayLabel' => $diaLabel,
        'mine'     => true,
        'nick'     => 'Você',
        'avatar'   => 'Você',
    ];

    echo json_encode($response);
    exit;

} catch (Throwable $e) {
    // Se quiser ver o erro real para debug, descomente a linha abaixo:
    // $response['error'] = $e->getMessage();
    $response['error'] = 'Erro interno ao salvar mensagem.';
    echo json_encode($response);
    exit;
}
