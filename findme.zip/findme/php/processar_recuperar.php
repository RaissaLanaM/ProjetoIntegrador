<?php
session_start();
require_once __DIR__ . '/../includes/conexao.php';

/**
 * Helper para redirecionar com mensagem
 */
function redirectWithMessage(string $msg, string $tipo = 'erro', string $para = '../html/recuperar_senha.php'): void
{
    $_SESSION['mensagem_' . $tipo] = $msg;
    header("Location: {$para}");
    exit;
}

// Garante que seja POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    redirectWithMessage("⚠️ Requisição inválida.");
}

// Coleta e normaliza o e-mail
$email = strtolower(trim($_POST['email'] ?? ''));

// Validação básica
if ($email === '') {
    redirectWithMessage("⚠️ Informe um e-mail para recuperar sua senha.");
}

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    redirectWithMessage("⚠️ E-mail inválido.");
}

try {
    $stmt = $conexao->prepare("
        SELECT id 
        FROM usuarios 
        WHERE email = :email 
        LIMIT 1
    ");
    $stmt->bindValue(':email', $email, PDO::PARAM_STR);
    $stmt->execute();

    $usuario = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($usuario) {
        // guarda o ID do usuário para a etapa de redefinição
        $_SESSION['usuario_reset'] = (int) $usuario['id'];

        // opcional: mensagem de "link enviado" (simulado)
        $_SESSION['mensagem_sucesso'] = "✅ Localizamos sua conta. Agora defina uma nova senha.";
        header("Location: ../html/redefinir_senha.php");
        exit;
    }

    // Não encontrou o e-mail
    redirectWithMessage("⚠️ E-mail não encontrado em nossa base.");

} catch (Throwable $e) {
    // Em produção você pode logar o erro:
    // error_log('ERRO RECUPERAR_SENHA: ' . $e->getMessage());
    redirectWithMessage("⚠️ Erro ao processar a recuperação de senha. Tente novamente.");
}
