<?php
session_start();
require_once __DIR__ . '/../includes/conexao.php';
require_once __DIR__ . '/../includes/upload_imagem.php';

/**
 * Redireciona com mensagem de erro/sucesso.
 *
 * @param string $msg
 * @param string $tipo 'erro' ou 'sucesso'
 * @param string $para caminho de destino
 */
function redirectWithMessage(string $msg, string $tipo = 'erro', string $para = '../html/criar_objeto.php'): void
{
    $_SESSION['mensagem_' . $tipo] = $msg;
    header("Location: {$para}");
    exit;
}

/* ===========================================================
   1) Verifica login
=========================================================== */
if (empty($_SESSION['usuario_id'])) {
    $_SESSION['mensagem_erro'] = "Você precisa estar logado para cadastrar um objeto.";
    header("Location: ../html/login.php");
    exit;
}

$id_usuario = (int) $_SESSION['usuario_id'];

/* Opcional: exige método POST */
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    redirectWithMessage("Requisição inválida para cadastro de objeto.");
}

/* ===========================================================
   2) Confirma se o usuário ainda existe (evita FK 1452)
=========================================================== */
try {
    $st = $conexao->prepare("SELECT id FROM usuarios WHERE id = :id LIMIT 1");
    $st->bindValue(':id', $id_usuario, PDO::PARAM_INT);
    $st->execute();

    if (!$st->fetch(PDO::FETCH_ASSOC)) {
        $_SESSION['mensagem_erro'] = "Sessão inválida. Faça login novamente.";
        header("Location: ../html/login.php");
        exit;
    }
} catch (PDOException $e) {
    redirectWithMessage("Erro ao validar sessão. Tente novamente em instantes.");
}

/* ===========================================================
   3) Coleta e valida os dados do formulário
=========================================================== */
$tipo_objeto      = $_POST['tipo_objeto']             ?? '';
$titulo           = trim($_POST['titulo']             ?? '');
$descricao        = trim($_POST['descricao']          ?? '');
$categoria        = trim($_POST['categoria']          ?? '');
$local_encontrado = trim($_POST['local_encontrado']   ?? '');
$data_encontrado  = $_POST['data_encontrado']         ?? '';
$latitude         = ($_POST['latitude']  ?? '') !== '' ? $_POST['latitude']  : null;
$longitude        = ($_POST['longitude'] ?? '') !== '' ? $_POST['longitude'] : null;

// Normaliza tipo
if (!in_array($tipo_objeto, ['achado', 'perdido', 'devolvido'], true)) {
    $tipo_objeto = 'perdido';
}

// Valida campos obrigatórios
if (
    $titulo === '' ||
    $descricao === '' ||
    $categoria === '' ||
    $local_encontrado === '' ||
    $data_encontrado === ''
) {
    redirectWithMessage("Preencha todos os campos obrigatórios.");
}

// Validação simples da data (YYYY-MM-DD)
$dtOk = DateTime::createFromFormat('Y-m-d', $data_encontrado);
if (!$dtOk || $dtOk->format('Y-m-d') !== $data_encontrado) {
    redirectWithMessage("Data inválida. Use o formato correto no campo de data.");
}

/* ===========================================================
   4) Processa upload e insere no banco
=========================================================== */
try {
    // Upload seguro (retorna null se não enviar)
    $imagem_nome = processarUploadImagem('imagem', 'uploads/objetos', 3_000_000); // 3MB

    $sql = "
        INSERT INTO objetos 
            (id_usuario, tipo_objeto, titulo, descricao, categoria, local_encontrado, 
             data_encontrado, imagem, latitude, longitude) 
        VALUES 
            (:id_usuario, :tipo_objeto, :titulo, :descricao, :categoria, :local_encontrado, 
             :data_encontrado, :imagem, :latitude, :longitude)
    ";

    $stmt = $conexao->prepare($sql);
    $stmt->bindValue(':id_usuario',      $id_usuario,      PDO::PARAM_INT);
    $stmt->bindValue(':tipo_objeto',     $tipo_objeto);
    $stmt->bindValue(':titulo',          $titulo);
    $stmt->bindValue(':descricao',       $descricao);
    $stmt->bindValue(':categoria',       $categoria);
    $stmt->bindValue(':local_encontrado',$local_encontrado);
    $stmt->bindValue(':data_encontrado', $data_encontrado);
    $stmt->bindValue(':imagem',          $imagem_nome); // pode ser null
    

    // latitude/longitude podem ser null
    if ($latitude === null) {
        $stmt->bindValue(':latitude', null, PDO::PARAM_NULL);
    } else {
        $stmt->bindValue(':latitude', $latitude);
    }

    if ($longitude === null) {
        $stmt->bindValue(':longitude', null, PDO::PARAM_NULL);
    } else {
        $stmt->bindValue(':longitude', $longitude);
    }

    $stmt->execute();

    redirectWithMessage("✅ Objeto cadastrado com sucesso!", 'sucesso', '../html/dashboard.php');

} catch (Throwable $e) {
    // Em produção você pode logar o erro:
    // error_log('ERRO CADASTRO_OBJETO: ' . $e->getMessage());
    redirectWithMessage("⚠️ Erro ao cadastrar o objeto. Tente novamente.");
}
