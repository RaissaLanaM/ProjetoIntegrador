<?php
// php/analise_denuncia.php

require_once __DIR__ . '/../includes/conexao.php';

/**
 * Função auxiliar: cria uma notificação para um usuário.
 */
function criarNotificacao(PDO $conexao, int $usuarioId, string $tipo, string $titulo, string $mensagem, string $link = '#')
{
    try {
        $st = $conexao->prepare("
            INSERT INTO notificacoes (usuario_id, tipo, titulo, mensagem, link_destino, lida, created_at)
            VALUES (:uid, :t, :tit, :msg, :lnk, 0, NOW())
        ");
        $st->execute([
            ':uid' => $usuarioId,
            ':t'   => $tipo,
            ':tit' => $titulo,
            ':msg' => $mensagem,
            ':lnk' => $link
        ]);
    } catch (Throwable $e) {
        error_log("ERRO AO CRIAR NOTIFICAÇÃO: " . $e->getMessage());
    }
}

/**
 * Analisa automaticamente uma denúncia aplicando heurísticas simples
 * e salva o resultado em `denuncias_avaliadas`.
 *
 * RETORNO:
 * - array ['resultado' => string, 'score' => int]
 * - false caso algo dê errado
 */
function analisarDenunciaAutomatica(PDO $conexao, int $denunciaId)
{
    try {

        /* ===========================================================
           1) BUSCA A DENÚNCIA + OBJETO
        ============================================================ */
        $sql = "
            SELECT 
                d.id AS denuncia_id,
                d.objeto_id,
                d.motivo,
                d.descricao AS desc_denuncia,
                d.id_usuario AS denunciante_id,
                o.id_usuario AS dono_id,
                o.titulo,
                o.descricao AS desc_obj,
                o.data_encontrado
            FROM denuncias d
            JOIN objetos o ON o.id = d.objeto_id
            WHERE d.id = :id
        ";

        $st = $conexao->prepare($sql);
        $st->bindValue(':id', $denunciaId, PDO::PARAM_INT);
        $st->execute();
        $row = $st->fetch(PDO::FETCH_ASSOC);

        if (!$row) return false;

        $donoId        = (int)$row['dono_id'];
        $denuncianteId = (int)$row['denunciante_id'];
        $tituloObj     = $row['titulo'] ?? '';

        /* ===========================================================
           2) ANÁLISE HEURÍSTICA
        ============================================================ */
        $score = 0;
        $motivo = strtolower($row['motivo'] ?? '');

        $texto = strtolower(
            ($row['desc_denuncia'] ?? '') . ' ' .
            ($row['desc_obj'] ?? '') . ' ' .
            ($row['titulo'] ?? '')
        );

        $suspeitas = [
            'pix','depósito','deposito','transferência','transferencia',
            'venda','comprar','whatsapp','zap','contato','adiantamento'
        ];

        foreach ($suspeitas as $kw) {
            if (str_contains($texto, $kw)) $score += 3;
        }

        if (in_array($motivo, ['fraude','informacao_falsa','golpe'], true)) {
            $score += 2;
        }
        if ($motivo === 'spam') {
            $score += 1;
        }

        // Nº denúncias no objeto
        $st = $conexao->prepare("SELECT COUNT(*) FROM denuncias WHERE objeto_id = :obj");
        $st->execute([':obj' => $row['objeto_id']]);
        if ((int)$st->fetchColumn() > 2) $score += 2;

        // Histórico do dono
        $st = $conexao->prepare("
            SELECT COUNT(*) 
            FROM denuncias d
            JOIN objetos o ON o.id = d.objeto_id
            WHERE o.id_usuario = :usr
        ");
        $st->execute([':usr' => $donoId]);
        if ((int)$st->fetchColumn() > 3) $score += 3;

        // Objeto recente
        if (!empty($row['data_encontrado'])) {
            if ((time() - strtotime($row['data_encontrado'])) / 3600 <= 24) {
                $score += 1;
            }
        }

        /* ===========================================================
           3) RESULTADO FINAL
        ============================================================ */
        if ($score >= 6) {
            $resultado = 'Provável golpe detectado';
        } elseif ($score >= 3) {
            $resultado = 'Suspeita de irregularidade';
        } else {
            $resultado = 'Sem evidências de golpe';
        }

        /* ===========================================================
           4) SALVA AVALIAÇÃO
        ============================================================ */
        $ins = $conexao->prepare("
            INSERT INTO denuncias_avaliadas (denuncia_id, resultado, score, data_analise)
            VALUES (:id, :res, :sc, NOW())
            ON DUPLICATE KEY UPDATE 
                resultado = VALUES(resultado),
                score     = VALUES(score),
                data_analise = VALUES(data_analise)
        ");
        $ins->execute([
            ':id' => $denunciaId,
            ':res'=> $resultado,
            ':sc' => $score
        ]);

        /* ===========================================================
           5) NOTIFICAÇÃO AUTOMÁTICA PARA O DONO DO OBJETO
        ============================================================ */
        criarNotificacao(
            $conexao,
            $donoId,
            'denuncia',
            'Seu anúncio foi analisado',
            "A denúncia sobre o anúncio \"$tituloObj\" foi analisada: $resultado.",
            '../telas/detalhe_objeto.php?id=' . $row['objeto_id']
        );

        /* ===========================================================
           6) OPCIONAL — NOTIFICAR O DENUNCIANTE
        ============================================================ */
        criarNotificacao(
            $conexao,
            $denuncianteId,
            'denuncia',
            'Sua denúncia foi analisada',
            "A denúncia enviada sobre o anúncio \"$tituloObj\" foi analisada: $resultado.",
            '../telas/detalhe_objeto.php?id=' . $row['objeto_id']
        );

        return [
            'resultado' => $resultado,
            'score'     => $score
        ];

    } catch (Throwable $e) {
        error_log("ERRO ANALISE_DENUNCIA: " . $e->getMessage());
        return false;
    }
}
