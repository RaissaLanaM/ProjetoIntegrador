<?php
session_start();
header('Content-Type: application/json; charset=utf-8');

require_once '../includes/conexao.php';

/**
 * Responde JSON e encerra o script.
 *
 * @param array $data
 * @param int   $statusCode
 * @return void
 */
function jsonResponse(array $data, int $statusCode = 200): void
{
    http_response_code($statusCode);
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit;
}

// Usuário precisa estar logado
if (empty($_SESSION['usuario_id'])) {
    jsonResponse(['messages' => [], 'typing' => false], 401);
}

$uid    = (int) $_SESSION['usuario_id'];
$cid    = isset($_GET['chat_id'])  ? (int) $_GET['chat_id']  : 0;
$lastId = isset($_GET['last_id'])  ? (int) $_GET['last_id']  : 0;

if ($cid <= 0) {
    jsonResponse(['messages' => [], 'typing' => false], 400);
}

try {
    /* ===========================================================
       1) Valida participação no chat e identifica o outro usuário
    ============================================================ */
    $sqlChat = "
        SELECT usuario1_id, usuario2_id
        FROM chats
        WHERE id = :cid
        LIMIT 1
    ";
    $stmt = $conexao->prepare($sqlChat);
    $stmt->execute([':cid' => $cid]);
    $chat = $stmt->fetch(PDO::FETCH_ASSOC);

    if (
        !$chat ||
        ($chat['usuario1_id'] != $uid && $chat['usuario2_id'] != $uid)
    ) {
        jsonResponse(['messages' => [], 'typing' => false], 403);
    }

    $outro = ($chat['usuario1_id'] == $uid)
        ? (int) $chat['usuario2_id']
        : (int) $chat['usuario1_id'];

    /* ===========================================================
       2) Busca novas mensagens com id > last_id
    ============================================================ */
    $sqlMsg = "
        SELECT id, de_usuario_id, mensagem, data_envio
        FROM mensagens
        WHERE chat_id = :cid
          AND id > :last
        ORDER BY id ASC
    ";

    $q = $conexao->prepare($sqlMsg);
    $q->execute([
        ':cid'  => $cid,
        ':last' => $lastId
    ]);

    $messages = [];

    while ($r = $q->fetch(PDO::FETCH_ASSOC)) {
        $ts = strtotime($r['data_envio']);

        $messages[] = [
            'id'       => (int) $r['id'],
            'mine'     => ((int) $r['de_usuario_id'] === $uid),
            'text'     => $r['mensagem'],
            'time'     => date('H:i', $ts),
            'dayLabel' => date('d/m/Y', $ts),
        ];
    }

    /* ===========================================================
       3) Verifica status de digitação (typing)
       Usa arquivo temporário por usuário (ping)
    ============================================================ */
    $baseDir = rtrim(sys_get_temp_dir(), DIRECTORY_SEPARATOR);
    $file    = $baseDir . DIRECTORY_SEPARATOR . "typing_findme_{$cid}_user_{$outro}.ping";

    $typing = false;
    if (is_file($file)) {
        $age = time() - filemtime($file);
        // Considera "digitando" se o ping for dos últimos 4 segundos
        $typing = ($age <= 4);
    }

    /* ===========================================================
       4) Resposta final
    ============================================================ */
    jsonResponse([
        'messages' => $messages,
        'typing'   => $typing,
    ]);

} catch (Throwable $e) {
    // Em produção, você pode logar o erro:
    // error_log('ERRO PULL_MENSAGENS: ' . $e->getMessage());
    jsonResponse(['messages' => [], 'typing' => false], 500);
}
