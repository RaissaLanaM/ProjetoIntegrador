<?php
/**
 * Atualização de objeto cadastrado no sistema FindMe.
 *
 * Responsável por:
 *  - validar sessão e permissão do usuário
 *  - carregar dados existentes
 *  - tratar upload (opcional)
 *  - atualizar informações no banco
 *  - remover imagem antiga, se necessário
 */

session_start();
require_once '../includes/conexao.php';
require_once '../includes/upload_imagem.php';

// Impede acesso não autenticado
if (!isset($_SESSION['usuario_id'])) {
    $_SESSION['mensagem_erro'] = "Faça login para continuar.";
    header("Location: ../html/login.php");
    exit;
}

$usuarioId = (int) $_SESSION['usuario_id'];

// Sanitização mínima dos campos recebidos
$id               = isset($_POST['id']) ? (int) $_POST['id'] : 0;
$tipo_objeto      = trim($_POST['tipo_objeto']      ?? '');
$titulo           = trim($_POST['titulo']           ?? '');
$descricao        = trim($_POST['descricao']        ?? '');
$categoria        = trim($_POST['categoria']        ?? '');
$local_encontrado = trim($_POST['local_encontrado'] ?? '');
$data_encontrado  = trim($_POST['data_encontrado']  ?? '');

if ($id <= 0) {
    $_SESSION['mensagem_erro'] = "Objeto inválido.";
    header("Location: ../html/dashboard.php");
    exit;
}

try {

    /* ===========================================================
       1) Carrega objeto e valida permissão
    ============================================================ */
    $s = $conexao->prepare("SELECT * FROM objetos WHERE id = :id LIMIT 1");
    $s->bindValue(':id', $id, PDO::PARAM_INT);
    $s->execute();
    $obj = $s->fetch(PDO::FETCH_ASSOC);

    if (!$obj) {
        $_SESSION['mensagem_erro'] = "Objeto não encontrado.";
        header("Location: ../html/dashboard.php");
        exit;
    }

    if ((int) $obj['id_usuario'] !== $usuarioId) {
        $_SESSION['mensagem_erro'] = "Você não pode editar este objeto.";
        header("Location: ../html/dashboard.php");
        exit;
    }

    /* ===========================================================
       2) Processa upload de imagem (opcional)
    ============================================================ */
    $novoNome = null;
    try {
        $novoNome = processarUploadImagem(
            'imagem',
            'uploads/objetos',
            3_000_000
        );
    } catch (RuntimeException $e) {
        // Não fatal — apenas impede o upload
        $_SESSION['mensagem_erro'] = "Erro ao enviar imagem: " . $e->getMessage();
        header("Location: ../html/editar_objeto.php?id=$id");
        exit;
    }

    /* ===========================================================
       3) Atualiza objeto
    ============================================================ */
    $sql = "
        UPDATE objetos SET
            tipo_objeto      = :tipo_objeto,
            titulo           = :titulo,
            descricao        = :descricao,
            categoria        = :categoria,
            local_encontrado = :local_encontrado,
            data_encontrado  = :data_encontrado
            " . ($novoNome ? ", imagem = :imagem" : "") . "
        WHERE id = :id
    ";

    $u = $conexao->prepare($sql);
    $u->bindValue(':tipo_objeto',      $tipo_objeto);
    $u->bindValue(':titulo',           $titulo);
    $u->bindValue(':descricao',        $descricao);
    $u->bindValue(':categoria',        $categoria);
    $u->bindValue(':local_encontrado', $local_encontrado);
    $u->bindValue(':data_encontrado',  $data_encontrado);
    if ($novoNome) {
        $u->bindValue(':imagem', $novoNome);
    }
    $u->bindValue(':id',               $id, PDO::PARAM_INT);
    $u->execute();

    /* ===========================================================
       4) Remove imagem antiga, se necessário
    ============================================================ */
    if ($novoNome && !empty($obj['imagem'])) {
        $old = dirname(__DIR__) . '/uploads/objetos/' . $obj['imagem'];
        if (is_file($old)) {
            @unlink($old);
        }
    }

    /* ===========================================================
       5) Finalização
    ============================================================ */
    $_SESSION['mensagem_sucesso'] = "Objeto atualizado com sucesso!";
    header("Location: ../html/dashboard.php");
    exit;

} catch (Throwable $e) {

    $_SESSION['mensagem_erro'] = "Erro ao atualizar objeto: " . $e->getMessage();
    header("Location: ../html/editar_objeto.php?id=" . $id);
    exit;

}
