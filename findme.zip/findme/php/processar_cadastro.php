<?php
session_start();
require_once '../includes/conexao.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    $_SESSION['mensagem_erro'] = "Método inválido.";
    header('Location: ../html/cadastro.php');
    exit();
}

$nome  = trim($_POST['nome'] ?? '');
$email = trim($_POST['email'] ?? '');
$senha = $_POST['senha'] ?? '';
$confirmar = $_POST['confirmar'] ?? '';

// validações básicas
if ($nome === '' || $email === '' || $senha === '' || $confirmar === '') {
    $_SESSION['mensagem_erro'] = "Preencha todos os campos.";
    header('Location: ../html/cadastro.php');
    exit();
}

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    $_SESSION['mensagem_erro'] = "E-mail inválido.";
    header('Location: ../html/cadastro.php');
    exit();
}

if ($senha !== $confirmar) {
    $_SESSION['mensagem_erro'] = "As senhas não coincidem.";
    header('Location: ../html/cadastro.php');
    exit();
}

// verifica se email já existe
$st = $conexao->prepare("SELECT id FROM usuarios WHERE email = :email LIMIT 1");
$st->bindValue(':email', $email, PDO::PARAM_STR);
$st->execute();

if ($st->fetch()) {
    $_SESSION['mensagem_erro'] = "Este e-mail já está cadastrado.";
    header('Location: ../html/cadastro.php');
    exit();
}

// cria hash da senha
$hash = password_hash($senha, PASSWORD_DEFAULT);

// insere usuário
$ins = $conexao->prepare("
    INSERT INTO usuarios (nome, email, senha)
    VALUES (:nome, :email, :senha)
");

$ok = $ins->execute([
    ':nome'  => $nome,
    ':email' => $email,
    ':senha' => $hash
]);

if ($ok) {
    $_SESSION['mensagem_sucesso'] = "Conta criada com sucesso! Agora você já pode fazer login.";
    header('Location: ../html/cadastro.php');
    exit();
} else {
    $_SESSION['mensagem_erro'] = "Ocorreu um erro ao criar sua conta. Tente novamente.";
    header('Location: ../html/cadastro.php');
    exit();
}
