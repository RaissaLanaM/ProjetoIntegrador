<?php
// php/notificacoes_marcar_lidas.php
session_start();
header('Content-Type: application/json; charset=utf-8');

if (!isset($_SESSION['usuario_id'])) {
    echo json_encode(['ok' => false, 'erro' => 'Não autenticado']);
    exit;
}

require_once __DIR__ . '/../includes/conexao.php';

$uid = (int) $_SESSION['usuario_id'];

try {
    $st = $conexao->prepare("
        UPDATE notificacoes
        SET lida = 1
        WHERE usuario_id = :uid AND lida = 0
    ");
    $st->bindValue(':uid', $uid, PDO::PARAM_INT);
    $st->execute();

    echo json_encode([
        'ok'       => true,
        'afetadas' => $st->rowCount()
    ]);
} catch (Throwable $e) {
    echo json_encode(['ok' => false, 'erro' => $e->getMessage()]);
}
