<?php
session_start();
require_once __DIR__ . '/../includes/conexao.php';

/**
 * Redireciona com mensagem de erro/sucesso.
 *
 * @param string $msg
 * @param string $tipo  'erro' ou 'sucesso'
 * @param string $para  caminho da página de destino
 */
function redirectWithMessage(string $msg, string $tipo = 'erro', string $para = '../html/login.php'): void
{
    $_SESSION['mensagem_' . $tipo] = $msg;
    header("Location: {$para}");
    exit;
}

// Garante que o login seja feito via POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    redirectWithMessage("⚠️ Método de requisição inválido.");
}

// Normaliza entradas
$email = strtolower(trim($_POST['email'] ?? ''));
$senha = $_POST['senha'] ?? '';

// Validação básica
if ($email === '' || $senha === '') {
    redirectWithMessage("⚠️ Preencha todos os campos.");
}

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    redirectWithMessage("⚠️ E-mail inválido.");
}

try {
    // Busca somente os campos necessários
    $sql = "SELECT id, nome, email, senha FROM usuarios WHERE email = :email LIMIT 1";
    $stmt = $conexao->prepare($sql);
    $stmt->bindValue(':email', $email, PDO::PARAM_STR);
    $stmt->execute();

    $usuario = $stmt->fetch(PDO::FETCH_ASSOC);

    // Verifica usuário + senha
    if ($usuario && password_verify($senha, $usuario['senha'])) {

        // Regenera ID de sessão pra evitar fixation
        session_regenerate_id(true);

        $_SESSION['usuario_id']   = (int) $usuario['id'];
        $_SESSION['usuario_nome'] = $usuario['nome'];

        // Se quiser, dá pra setar uma mensagem de boas-vindas:
        // $_SESSION['mensagem_sucesso'] = "🎉 Bem-vindo(a), {$usuario['nome']}!";

        header("Location: ../html/index.php");
        exit;
    }

    // Falha no login
    redirectWithMessage("⚠️ E-mail ou senha inválidos.");

} catch (Throwable $e) {
    // Em produção você poderia logar o erro:
    // error_log('ERRO LOGIN: ' . $e->getMessage());
    redirectWithMessage("⚠️ Erro ao tentar fazer login. Tente novamente em instantes.");
}
