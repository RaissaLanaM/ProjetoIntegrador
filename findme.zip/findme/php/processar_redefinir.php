<?php
session_start();
require_once __DIR__ . '/../includes/conexao.php';

/**
 * Helper para redirecionar com mensagem
 */
function redirectWithMessage(string $msg, string $tipo = 'erro', string $para = '../html/redefinir_senha.php'): void
{
    $_SESSION['mensagem_' . $tipo] = $msg;
    header("Location: {$para}");
    exit;
}

// Garante que veio do fluxo correto
if (empty($_SESSION['usuario_reset'])) {
    header("Location: ../html/recuperar_senha.php");
    exit;
}

// Garante que seja POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    redirectWithMessage("⚠️ Requisição inválida.");
}

$senha     = $_POST['senha']     ?? '';
$confirmar = $_POST['confirmar'] ?? '';

// Validações básicas
if ($senha === '' || $confirmar === '') {
    redirectWithMessage("⚠️ Preencha todos os campos.");
}

if ($senha !== $confirmar) {
    redirectWithMessage("⚠️ As senhas não coincidem.");
}

if (strlen($senha) < 6) {
    redirectWithMessage("⚠️ A senha deve ter pelo menos 6 caracteres.");
}

try {
    // Gera hash seguro da nova senha
    $senhaHash = password_hash($senha, PASSWORD_DEFAULT, ['cost' => 12]);

    $stmt = $conexao->prepare("
        UPDATE usuarios
        SET senha = :senha
        WHERE id = :id
        LIMIT 1
    ");
    $stmt->execute([
        ':senha' => $senhaHash,
        ':id'    => (int) $_SESSION['usuario_reset']
    ]);

    // Limpa flag de reset
    unset($_SESSION['usuario_reset']);

    $_SESSION['mensagem_sucesso'] = "✅ Senha redefinida com sucesso! Faça login.";
    header("Location: ../html/login.php");
    exit;

} catch (Throwable $e) {
    // Em produção, você pode logar o erro:
    // error_log('ERRO REDEFINIR_SENHA: ' . $e->getMessage());
    redirectWithMessage("⚠️ Erro ao redefinir a senha. Tente novamente.");
}
