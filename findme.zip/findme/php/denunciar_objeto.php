<?php
session_start();
require_once '../includes/conexao.php';

/**
 * Redireciona para o dashboard com mensagem de feedback.
 *
 * @param string $msg  Mensagem a ser exibida
 * @param string $tipo 'sucesso' ou 'erro'
 */
function back_to_dashboard(string $msg, string $tipo = 'erro'): void
{
    if ($tipo === 'sucesso') {
        $_SESSION['mensagem_sucesso'] = $msg;
    } else {
        $_SESSION['mensagem_erro'] = $msg;
    }

    header("Location: ../html/dashboard.php");
    exit;
}

// Garante que o usuário está logado
if (empty($_SESSION['usuario_id'])) {
    $_SESSION['mensagem_erro'] = "Faça login para continuar.";
    header("Location: ../html/login.php");
    exit;
}

// Opcional: exige método POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    back_to_dashboard("Método de requisição inválido.");
}

$usuarioLogado = (int) $_SESSION['usuario_id'];

/* ===========================================================
   1) Validação de CSRF
=========================================================== */
$tokenPost = $_POST['csrf']              ?? '';
$tokenSess = $_SESSION['csrf_denuncia'] ?? '';

if (!$tokenPost || !$tokenSess || !hash_equals($tokenSess, $tokenPost)) {
    back_to_dashboard("Requisição inválida ao enviar denúncia.");
}

/* ===========================================================
   2) Coleta e validação dos dados
=========================================================== */
$objeto_id   = isset($_POST['objeto_id']) ? (int) $_POST['objeto_id'] : 0;
$motivo_base = trim($_POST['motivo_base'] ?? '');
$detalhes    = trim($_POST['detalhes']    ?? '');

// Validação básica de obrigatórios
if ($objeto_id <= 0 || $motivo_base === '' || $detalhes === '') {
    back_to_dashboard("Preencha todos os campos da denúncia.");
}

// Motivos permitidos (rótulo)
$motivosPermitidos = [
    'Golpe ou fraude',
    'Informações falsas ou enganosas',
    'Conteúdo impróprio / sensível',
    'Anúncio duplicado / repetido',
    'Linguagem ofensiva ou abusiva',
    'Outro motivo'
];

if (!in_array($motivo_base, $motivosPermitidos, true)) {
    $motivo_base = 'Outro motivo';
}

/* ===========================================================
   3) Confirma objeto e regra de não denunciar o próprio
=========================================================== */
$sql = "SELECT id, id_usuario, titulo, denuncia_total, denuncia_nivel, denuncia_avisar 
        FROM objetos 
        WHERE id = :id 
        LIMIT 1";
$stmt = $conexao->prepare($sql);
$stmt->bindValue(':id', $objeto_id, PDO::PARAM_INT);
$stmt->execute();
$obj = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$obj) {
    back_to_dashboard("Objeto não encontrado para denúncia.");
}

if ((int) $obj['id_usuario'] === $usuarioLogado) {
    back_to_dashboard("Você não pode denunciar um objeto que você mesmo cadastrou.");
}

/* ===========================================================
   4) Monta campos para inserção
=========================================================== */
// Limita tamanho do texto descritivo
$detalhes_sanit = mb_substr($detalhes, 0, 500, 'UTF-8');

// Campo "motivo" guarda o rótulo + resumo
$motivo_full = $motivo_base . ' — ' . $detalhes_sanit;

/* ===========================================================
   5) Inserção da denúncia + atualização de stats + notificação
=========================================================== */

try {
    $conexao->beginTransaction();

    // 5.1 – Insere a denúncia
    $sqlInsert = "
        INSERT INTO denuncias (objeto_id, usuario_id, motivo, data_denuncia)
        VALUES (:objeto_id, :usuario_id, :motivo, NOW())
    ";
    $stmtIns = $conexao->prepare($sqlInsert);
    $stmtIns->bindValue(':objeto_id',  $objeto_id,     PDO::PARAM_INT);
    $stmtIns->bindValue(':usuario_id', $usuarioLogado, PDO::PARAM_INT);
    $stmtIns->bindValue(':motivo',     $motivo_full,   PDO::PARAM_STR);
    $stmtIns->execute();

    // 5.2 – Recalcula quantas denúncias este objeto tem
    $sqlCount = "SELECT COUNT(*) AS total FROM denuncias WHERE objeto_id = :oid";
    $stmtCount = $conexao->prepare($sqlCount);
    $stmtCount->bindValue(':oid', $objeto_id, PDO::PARAM_INT);
    $stmtCount->execute();
    $denunciasTotal = (int)$stmtCount->fetchColumn();

    // Define nível de risco (ajuste como preferir)
    // 0 = sem risco, 1 = leve, 2 = moderado, 3 = grave
    $nivel = 0;
    if ($denunciasTotal >= 6) {
        $nivel = 3;
    } elseif ($denunciasTotal >= 3) {
        $nivel = 2;
    } elseif ($denunciasTotal >= 1) {
        $nivel = 1;
    }

    // Flag pra saber se devemos avisar o dono (1 = avisar, 0 = não)
    $avisar = ($denunciasTotal >= 3) ? 1 : 0;

    // 5.3 – Atualiza campos de denúncia no objeto
    $sqlUpdObj = "
        UPDATE objetos
        SET denuncia_total   = :total,
            denuncia_nivel   = :nivel,
            denuncia_avisar  = :avisar
        WHERE id = :oid
    ";
    $stmtUpdObj = $conexao->prepare($sqlUpdObj);
    $stmtUpdObj->execute([
        ':total'  => $denunciasTotal,
        ':nivel'  => $nivel,
        ':avisar' => $avisar,
        ':oid'    => $objeto_id,
    ]);

    // 5.4 – Se atingiu o limite e ainda NÃO tinha sido avisado, cria notificação pro dono
    // re-carrega o objeto só pra garantir o valor anterior de denuncia_avisar
    $jaAvisouAntes = (int)$obj['denuncia_avisar'];

    if ($denunciasTotal >= 3 && $jaAvisouAntes == 0) {

        $mensagem = 'O anúncio "' . $obj['titulo'] . '" recebeu múltiplas denúncias. '
                  . 'Verifique as informações antes de prosseguir.';

        $sqlNotif = "
            INSERT INTO notificacoes (usuario_id, tipo, titulo, mensagem, lida, created_at, link_destino)
            VALUES (:uid, 'denuncia', 'Anúncio com denúncias', :msg, 0, NOW(), :link)
        ";

        $stmtNotif = $conexao->prepare($sqlNotif);
        $stmtNotif->execute([
            ':uid'  => (int)$obj['id_usuario'],  // **dono do anúncio**
            ':msg'  => $mensagem,
            ':link' => '../html/detalhes_objeto.php?id=' . $objeto_id,
        ]);
    }

    $conexao->commit();

    // Invalida o token para evitar replay
    unset($_SESSION['csrf_denuncia']);

    back_to_dashboard(
        "Denúncia enviada com sucesso. O anúncio agora é marcado como potencialmente arriscado para outros usuários.",
        'sucesso'
    );

} catch (PDOException $e) {

    if ($conexao->inTransaction()) {
        $conexao->rollBack();
    }

    // Ex.: se houver UNIQUE(objeto_id, usuario_id)
    if ($e->getCode() === '23000') {
        back_to_dashboard("Você já enviou uma denúncia para este anúncio. Agradecemos sua colaboração!");
    }

    back_to_dashboard("Erro ao registrar denúncia. Tente novamente mais tarde.");
}
