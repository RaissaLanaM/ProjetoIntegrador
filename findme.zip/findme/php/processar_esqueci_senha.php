<?php
session_start();
require_once __DIR__ . '/../includes/conexao.php';

/**
 * Helper para redirecionar com mensagem
 */
function redirectWithMessage(string $msg, string $tipo = 'erro', string $to = '../html/recuperar_senha.php'): void {
    $_SESSION['mensagem_' . $tipo] = $msg;
    header("Location: {$to}");
    exit;
}

// Coleta e normaliza o e-mail
$email = strtolower(trim($_POST['email'] ?? ''));

// Validação básica
if ($email === '') {
    redirectWithMessage("⚠️ Informe o e-mail cadastrado.");
}

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    redirectWithMessage("⚠️ E-mail inválido.");
}

try {
    // Verifica se existe usuário com esse e-mail
    $sql = "SELECT id FROM usuarios WHERE email = :email LIMIT 1";
    $stmt = $conexao->prepare($sql);
    $stmt->bindValue(':email', $email, PDO::PARAM_STR);
    $stmt->execute();

    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($user) {
        // Guardamos o ID do usuário na sessão para permitir redefinição
        $_SESSION['usuario_reset'] = (int) $user['id'];

        // Mensagem de sucesso (poderia simular "envio de link" para fins de TCC)
        $_SESSION['mensagem_sucesso'] = "✅ Um link (simulado) para redefinição foi gerado. Prossiga para cadastrar uma nova senha.";
        
        // Redireciona para a tela de redefinição de senha
        header("Location: ../html/redefinir_senha.php");
        exit;
    }

    // Se não encontrou, informa erro
    redirectWithMessage("⚠️ E-mail não encontrado em nossa base de dados.");

} catch (Throwable $e) {
    // Em produção você poderia logar: error_log('ERRO RECUPERAR: '.$e->getMessage());
    redirectWithMessage("⚠️ Erro ao processar a recuperação de senha. Tente novamente.");
}
