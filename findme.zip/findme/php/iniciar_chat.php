<?php
// /php/iniciar_chat.php
session_start();
require_once __DIR__ . '/../includes/conexao.php';

/**
 * Helper simples para redirecionar com mensagem
 */
function redirectWithMessage(string $msg, string $tipo = 'erro', string $para = '../html/listar_chats.php'): void
{
    $_SESSION['mensagem_' . $tipo] = $msg;
    header("Location: {$para}");
    exit();
}

// Verifica login
if (empty($_SESSION['usuario_id'])) {
    $_SESSION['mensagem_erro'] = "Faça login para conversar.";
    header("Location: ../html/login.php");
    exit();
}

$meuId  = (int) $_SESSION['usuario_id'];
$donoId = isset($_GET['id_dono']) ? (int) $_GET['id_dono'] : 0;

// validações básicas
if ($donoId <= 0) {
    redirectWithMessage("Destinatário inválido.");
}

if ($donoId === $meuId) {
    redirectWithMessage("Você não pode iniciar um chat consigo mesmo.");
}

try {
    // 0) Garante que o usuário destino existe
    $chkUser = $conexao->prepare("
        SELECT id 
        FROM usuarios 
        WHERE id = :id 
        LIMIT 1
    ");
    $chkUser->bindValue(':id', $donoId, PDO::PARAM_INT);
    $chkUser->execute();

    if (!$chkUser->fetchColumn()) {
        redirectWithMessage("Usuário destino não encontrado.");
    }

    // 1) Verifica se já existe chat entre os dois usuários
    $sql = "
        SELECT id
        FROM chats
        WHERE (usuario1_id = :u1 AND usuario2_id = :u2)
           OR (usuario1_id = :u3 AND usuario2_id = :u4)
        LIMIT 1
    ";
    $st = $conexao->prepare($sql);
    $st->bindValue(':u1', $meuId,  PDO::PARAM_INT);
    $st->bindValue(':u2', $donoId, PDO::PARAM_INT);
    $st->bindValue(':u3', $donoId, PDO::PARAM_INT);
    $st->bindValue(':u4', $meuId,  PDO::PARAM_INT);
    $st->execute();

    $chat = $st->fetch(PDO::FETCH_ASSOC);

    if ($chat && isset($chat['id'])) {
        // Já existe chat → reaproveita
        $chatId = (int) $chat['id'];
    } else {
        // 2) Não existe? Cria o chat
        $ins = $conexao->prepare("
            INSERT INTO chats (usuario1_id, usuario2_id, status, criado_em)
            VALUES (:a, :b, 'aberto', NOW())
        ");
        $ins->bindValue(':a', $meuId,  PDO::PARAM_INT);
        $ins->bindValue(':b', $donoId, PDO::PARAM_INT);
        $ins->execute();

        $chatId = (int) $conexao->lastInsertId();
    }

    // 3) Redireciona direto para a conversa
    header("Location: ../html/chat.php?id=" . $chatId);
    exit();

} catch (Throwable $e) {
    // Enquanto estamos desenvolvendo, é útil ver o erro real:
    $_SESSION['mensagem_erro'] =
        "Não foi possível iniciar o chat no momento. Tente novamente mais tarde."
        . " [Detalhes técnicos: " . $e->getMessage() . "]";

    header("Location: ../html/listar_chats.php");
    exit();
}
