<?php
session_start();
require_once '../includes/conexao.php';

// Sempre responde JSON
header('Content-Type: application/json; charset=utf-8');

/**
 * Helper simples para responder JSON com código HTTP.
 */
function jsonResponse(array $data, int $statusCode = 200): void
{
    http_response_code($statusCode);
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit;
}

// Verifica se o usuário está autenticado
if (empty($_SESSION['usuario_id'])) {
    jsonResponse(['erro' => 'Não autorizado.'], 401);
}

$idUsuarioSessao = (int) $_SESSION['usuario_id'];

// Valida parâmetro "id" (id do outro usuário)
$paraUsuarioId = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);

if (!$paraUsuarioId || $paraUsuarioId <= 0) {
    jsonResponse(['erro' => 'ID inválido.'], 400);
}

try {
    $sql = "
        SELECT 
            de_usuario_id, 
            para_usuario_id, 
            mensagem, 
            DATE_FORMAT(data_envio, '%H:%i') AS hora
        FROM mensagens
        WHERE
            (de_usuario_id = :user AND para_usuario_id = :dest)
            OR
            (de_usuario_id = :dest AND para_usuario_id = :user)
        ORDER BY data_envio ASC
    ";

    $stmt = $conexao->prepare($sql);
    $stmt->bindValue(':user', $idUsuarioSessao, PDO::PARAM_INT);
    $stmt->bindValue(':dest', $paraUsuarioId, PDO::PARAM_INT);
    $stmt->execute();

    $mensagens = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Mantém o mesmo formato esperado pelo front: array de mensagens
    echo json_encode($mensagens, JSON_UNESCAPED_UNICODE);

} catch (Throwable $e) {
    // Em produção, logaria o erro em arquivo
    // error_log('ERRO BUSCAR MENSAGENS: ' . $e->getMessage());
    jsonResponse(['erro' => 'Erro ao buscar mensagens.'], 500);
}
