<?php
// /includes/footer.php
?>
<footer class="fm-footer">
    <p>&copy; <?= date('Y'); ?> - Projeto TCC FindMe</p>
</footer>
