<?php
/**
 * Registra ações realizadas sobre um objeto (edição, exclusão, devolução, etc.)
 *
 * TABELA SUGERIDA (MySQL/MariaDB):
 * --------------------------------------------------------
 *  id            INT AI PK
 *  objeto_id     INT NOT NULL
 *  usuario_id    INT NOT NULL
 *  acao          VARCHAR(30) NOT NULL
 *  detalhes      JSON / TEXT NULL
 *  criado_em     TIMESTAMP DEFAULT CURRENT_TIMESTAMP
 * --------------------------------------------------------
 *
 * @param PDO    $conexao    Conexão com o banco
 * @param int    $objetoId   ID do objeto afetado
 * @param int    $usuarioId  ID do usuário que realizou a ação
 * @param string $acao       Tipo de ação (ex: 'editar', 'excluir', 'devolver')
 * @param array  $detalhes   Informações adicionais (opcional)
 *
 * @return bool  Retorna true se registrado com sucesso, false se falhar
 */
function registrarHistoricoEdicao(
    PDO $conexao,
    int $objetoId,
    int $usuarioId,
    string $acao,
    array $detalhes = []
): bool {

    try {
        // Segurança: normaliza ação e evita strings muito grandes
        $acao = trim($acao);
        if ($acao === '') {
            throw new InvalidArgumentException('Ação inválida para histórico.');
        }

        // JSON seguro
        $jsonDetalhes = json_encode(
            $detalhes,
            JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PARTIAL_OUTPUT_ON_ERROR
        );

        $sql = "
            INSERT INTO historico_edicao (objeto_id, usuario_id, acao, detalhes)
            VALUES (:objeto_id, :usuario_id, :acao, :detalhes)
        ";

        $stmt = $conexao->prepare($sql);
        $stmt->bindValue(':objeto_id', $objetoId, PDO::PARAM_INT);
        $stmt->bindValue(':usuario_id', $usuarioId, PDO::PARAM_INT);
        $stmt->bindValue(':acao', $acao, PDO::PARAM_STR);
        $stmt->bindValue(':detalhes', $jsonDetalhes, PDO::PARAM_STR);

        return $stmt->execute();
    } catch (Throwable $e) {
        // Aqui você pode logar o erro em um arquivo .log
        // error_log("ERRO HISTORICO: ".$e->getMessage());
        return false;
    }
}
