<?php
/**
 * processarUploadImagem
 * ---------------------
 * Função segura para upload de imagens.
 *
 * Recursos incluídos:
 * - Validação de tamanho
 * - Validação real do MIME (não só extensão)
 * - Proteção contra extensão dupla
 * - Geração de nome aleatório seguro
 * - Criação automática da pasta de destino
 * - Permissões adequadas
 * - Retorno somente do NOME do arquivo salvo
 *
 * @param string $campo       Nome do campo <input type="file">
 * @param string $subdir      Subpasta a partir da raiz (ex: "uploads/objetos")
 * @param int    $tamanhoMax  Tamanho máximo permitido em bytes (default: 3MB)
 *
 * @return string|null        Nome seguro do arquivo salvo / null se não enviou nada
 * @throws RuntimeException   Em caso de falha ou upload inválido
 */
function processarUploadImagem(
    string $campo,
    string $subdir = 'uploads/objetos',
    int $tamanhoMax = 3_000_000
): ?string {

    /* ======= Se o usuário não enviou arquivo ======= */
    if (
        empty($_FILES[$campo]) ||
        $_FILES[$campo]['error'] === UPLOAD_ERR_NO_FILE
    ) {
        return null;
    }

    $file = $_FILES[$campo];

    /* ======= Valida erros nativos do PHP ======= */
    if ($file['error'] !== UPLOAD_ERR_OK) {
        throw new RuntimeException("Falha no upload (código: {$file['error']}).");
    }

    /* ======= Valida tamanho ======= */
    if ($file['size'] > $tamanhoMax) {
        $maxMb = number_format($tamanhoMax / 1_000_000, 1);
        throw new RuntimeException("A imagem excede o tamanho máximo permitido de {$maxMb}MB.");
    }

    /* ======= Valida tipo real do arquivo ======= */
    $finfo = new finfo(FILEINFO_MIME_TYPE);
    $mime  = $finfo->file($file['tmp_name']) ?: '';

    $extensoesPermitidas = [
        'image/jpeg' => 'jpg',
        'image/png'  => 'png',
        'image/webp' => 'webp',
        'image/gif'  => 'gif',
    ];

    if (!isset($extensoesPermitidas[$mime])) {
        throw new RuntimeException('Formato de imagem não permitido.');
    }

    $ext = $extensoesPermitidas[$mime];

    /* ======= Resolve caminho absoluto ======= */
    $baseDir = dirname(__DIR__); // raiz do projeto
    $destDir = $baseDir . DIRECTORY_SEPARATOR . trim($subdir, '/');

    /* ======= Cria pasta se não existir ======= */
    if (!is_dir($destDir)) {
        if (!mkdir($destDir, 0775, true) && !is_dir($destDir)) {
            throw new RuntimeException('Não foi possível criar a pasta de uploads.');
        }
    }

    /* ======= Gera nome seguro, aleatório e curto ======= */
    $nomeSeguro = bin2hex(random_bytes(8)) . '.' . $ext;
    $destinoFs  = $destDir . DIRECTORY_SEPARATOR . $nomeSeguro;

    /* ======= Move o arquivo ======= */
    if (!move_uploaded_file($file['tmp_name'], $destinoFs)) {
        throw new RuntimeException('Não foi possível salvar o arquivo enviado.');
    }

    @chmod($destinoFs, 0644);

    /* ======= Retorna apenas o nome do arquivo ======= */
    return $nomeSeguro;
}
