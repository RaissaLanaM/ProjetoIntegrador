<?php
// Header global com contador + preview de notificações

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$usuarioId = $_SESSION['usuario_id'] ?? null;
$notificacoesNaoLidas = 0;

// Busca contador inicial de notificações não lidas
if ($usuarioId) {
    require_once __DIR__ . '/conexao.php';

    try {
        $st = $conexao->prepare("
            SELECT COUNT(*)
            FROM notificacoes
            WHERE usuario_id = :uid AND lida = 0
        ");
        $st->bindValue(':uid', $usuarioId, PDO::PARAM_INT);
        $st->execute();
        $notificacoesNaoLidas = (int) $st->fetchColumn();
    } catch (Throwable $e) {
        $notificacoesNaoLidas = 0;
    }
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FindMe</title>

    <!-- CSS do cabeçalho -->
    <link rel="stylesheet" href="../assets/css/header.css">

    <!-- Fonte global -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;700&display=swap" rel="stylesheet">

    <!-- Ícone do site -->
    <link rel="icon" type="image/png" href="../assets/img/logo.png">

    <!-- Estilos extras para notificações -->
    <style>
      .notif-icon-wrapper {
        position: relative;
        cursor: pointer;
        display: inline-flex;
        align-items: center;
        gap: 6px;
        font-weight: 500;
        color: #ffffff;
      }

      .notif-badge {
        position: absolute;
        top: -6px;
        right: -10px;
        background: #e53935;
        color: #fff;
        font-size: 0.7rem;
        padding: 2px 6px;
        border-radius: 999px;
        font-weight: 700;
        box-shadow: 0 3px 6px rgba(0, 0, 0, 0.25);
      }

      .notif-dropdown {
        position: fixed;          /* acompanha o header fixo */
        top: 70px;                /* logo abaixo do header */
        right: 16px;
        width: 320px;
        max-height: 420px;
        background: #ffffff;
        border-radius: 14px;
        box-shadow: 0 18px 40px rgba(15, 41, 90, 0.25);
        border: 1px solid rgba(44, 116, 179, 0.15);
        display: flex;
        flex-direction: column;
        overflow: hidden;
        z-index: 2500;
      }

      .notif-dropdown[hidden] {
        display: none;
      }

      .notif-item {
        padding: 10px 14px;
        font-size: 0.85rem;
        border-bottom: 1px solid #f3f4f6;
        text-decoration: none;
        color: #1f2933;
        display: block;
      }

      .notif-item:last-child {
        border-bottom: none;
      }

      .notif-item:hover {
        background: #f3f4ff;
      }

      .notif-item strong {
        display: block;
        font-weight: 600;
        color: #1a3d6d;
        margin-bottom: 2px;
      }

      .notif-item span {
        display: block;
      }

      .notif-item small {
        display: block;
        color: #6b7280;
        margin-top: 2px;
      }

      .notif-item.nao-lida {
        background: #fef2f2;
      }

      .notif-vazio {
        padding: 16px;
        text-align: center;
        font-size: 0.85rem;
        color: #6b7280;
      }
    </style>
</head>
<body>
    <!-- Cabeçalho fixo -->
    <header class="fm-header">
        <div class="logo">
            <img src="../assets/imagens/logo-findme.png" alt="FindMe">
            FindMe
        </div>

        <!-- Botão hamburguer (mobile) -->
        <button class="menu-toggle" id="menu-toggle" aria-label="Abrir Menu">☰</button>

        <!-- Navegação -->
        <nav id="menu" class="fm-nav">
            <a href="dashboard.php">🏠 Início</a>
            <a href="criar_objeto.php">📦 Cadastrar Objeto</a>
            <a href="listar_objetos.php">🔍 Listar Objetos</a>
            <a href="listar_chats.php">💬 Chats</a>

            <?php if ($usuarioId): ?>
                <!-- Sininho de notificações -->
                <div class="notif-icon-wrapper" id="notif-btn">
                    🔔 Notificações
                    <span
                        id="notif-badge"
                        class="notif-badge"
                        <?= $notificacoesNaoLidas > 0 ? '' : 'hidden'; ?>
                    >
                        <?= $notificacoesNaoLidas > 9 ? '9+' : $notificacoesNaoLidas; ?>
                    </span>
                </div>
            <?php endif; ?>

            <a href="perfil.php">👤 Meu Perfil</a>
            <a href="../php/logout.php">🚪 Sair</a>
        </nav>
    </header>

    <!-- Dropdown de notificações -->
    <div id="notif-dropdown" class="notif-dropdown" hidden></div>

    <script>
        // MENU MOBILE
        const toggle = document.getElementById('menu-toggle');
        const menu   = document.getElementById('menu');

        if (toggle && menu) {
          toggle.addEventListener('click', () => {
            toggle.classList.toggle('active');
            menu.classList.toggle('active');
          });
        }

        // ==== NOTIFICAÇÕES ====
        const notifBtn    = document.getElementById('notif-btn');
        const notifBox    = document.getElementById('notif-dropdown');
        const notifBadge  = document.getElementById('notif-badge');

        async function carregarNotificacoes() {
          try {
            const resp = await fetch('../php/notificacoes_listar.php');
            const data = await resp.json();

            const qtd = data.nao_lidas || 0;

            // Atualiza badge
            if (notifBadge) {
              if (qtd > 0) {
                notifBadge.hidden = false;
                notifBadge.textContent = qtd > 9 ? '9+' : qtd;
              } else {
                notifBadge.hidden = true;
              }
            }

            // Monta lista
            if (!data.itens || data.itens.length === 0) {
              notifBox.innerHTML = '<div class="notif-vazio">Você ainda não possui notificações.</div>';
              return;
            }

            notifBox.innerHTML = data.itens.slice(0, 6).map(n => {
              const titulo   = n.titulo     || 'Notificação';
              const mensagem = n.mensagem   || '';
              const dataLbl  = n.data_label || '';
              const link     = n.link       || '#';  // vem de notificacoes_listar.php

              const classe   = n.lida ? 'lida' : 'nao-lida';

              return `
                <a class="notif-item ${classe}" href="${link}">
                  <strong>${titulo}</strong>
                  <span>${mensagem}</span>
                  <small>${dataLbl}</small>
                </a>
              `;
            }).join('');
          } catch (e) {
            console.error('Erro ao carregar notificações', e);
            notifBox.innerHTML = '<div class="notif-vazio">Erro ao carregar notificações.</div>';
          }
        }

        async function marcarNotificacoesLidas() {
          try {
            await fetch('../php/notificacoes_marcar_lidas.php', { method: 'POST' });
          } catch (e) {
            console.error('Erro ao marcar notificações como lidas', e);
          }
        }

        if (notifBtn && notifBox) {
          notifBtn.addEventListener('click', async () => {
            const estavaEscondido = notifBox.hasAttribute('hidden');

            if (estavaEscondido) {
              await carregarNotificacoes();
              await marcarNotificacoesLidas();
              notifBox.removeAttribute('hidden');
            } else {
              notifBox.setAttribute('hidden', '');
            }
          });

          // Fecha dropdown ao clicar fora
          document.addEventListener('click', (ev) => {
            if (!notifBox.hasAttribute('hidden')) {
              if (!notifBox.contains(ev.target) && !notifBtn.contains(ev.target)) {
                notifBox.setAttribute('hidden', '');
              }
            }
          });

          // Carrega badge inicial
          carregarNotificacoes();
        }
    </script>
