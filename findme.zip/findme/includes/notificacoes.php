<?php
// includes/notificacoes.php

/**
 * Cria uma notificação para um usuário.
 *
 * @param PDO    $conexao    Conexão PDO já aberta
 * @param int    $usuarioId  ID do usuário que vai receber a notificação
 * @param string $tipo       Tipo simples (ex: 'chat', 'denuncia', 'avaliacao')
 * @param string $titulo     Título curto
 * @param string $mensagem   Texto da mensagem
 *
 * @return bool true se salvou, false se deu erro
 */
function criarNotificacao(PDO $conexao, int $usuarioId, string $tipo, string $titulo, string $mensagem): bool
{
    try {
        $sql = "INSERT INTO notificacoes (usuario_id, tipo, titulo, mensagem, lida, created_at)
                VALUES (:uid, :tipo, :titulo, :msg, 0, NOW())";
        $st = $conexao->prepare($sql);
        return $st->execute([
            ':uid'   => $usuarioId,
            ':tipo'  => mb_substr($tipo, 0, 50),
            ':titulo'=> mb_substr($titulo, 0, 120),
            ':msg'   => mb_substr($mensagem, 0, 255),
        ]);
    } catch (Throwable $e) {
        // Se der erro, só retorna false para não quebrar o fluxo principal
        return false;
    }
}
