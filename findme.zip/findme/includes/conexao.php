
<?php
/**
 * Arquivo de conexão com o banco de dados.
 * 
 * Responsável por criar a conexão PDO com o MySQL utilizando o banco "tcc".
 * Em caso de erro, registra no log do servidor e exibe uma mensagem genérica
 * para o usuário final.
 */

$host    = 'localhost';
$usuario = 'root';    // usuário padrão do XAMPP
$senha   = '';        // senha padrão em branco no XAMPP
$banco   = 'tcc';     // nome do banco de dados

$dsn = "mysql:host={$host};dbname={$banco};charset=utf8mb4";

try {
    $conexao = new PDO($dsn, $usuario, $senha, [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION, // lança exceções em erros
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,       // retorna arrays associativos por padrão
        PDO::ATTR_EMULATE_PREPARES   => false,                  // usa prepared statements nativos
    ]);
} catch (PDOException $e) {
    // Em produção, nunca exiba detalhes do erro para o usuário final.
    // O erro técnico vai para o log do servidor.
    error_log('Erro de conexão com o banco de dados: ' . $e->getMessage());

    // Mensagem amigável para quem está usando o sistema.
    die('Erro ao conectar ao banco de dados. Tente novamente mais tarde.');
}
