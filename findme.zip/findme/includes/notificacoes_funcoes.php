<?php
// includes/notificacoes_funcoes.php

/**
 * Cria uma notificação para um usuário.
 *
 * @param PDO    $conexao      Conexão PDO já aberta.
 * @param int    $usuarioId    ID do usuário que vai receber a notificação.
 * @param string $tipo         'chat', 'denuncia', 'avaliacao', etc.
 * @param string $titulo       Título curto da notificação.
 * @param string $mensagem     Texto principal.
 * @param string|null $link    Link de destino quando o usuário clicar.
 */
function criar_notificacao(PDO $conexao, int $usuarioId, string $tipo, string $titulo, string $mensagem, ?string $link = null): void
{
    $sql = "
        INSERT INTO notificacoes (
            usuario_id,
            tipo,
            titulo,
            mensagem,
            lida,
            created_at,
            link_destino
        ) VALUES (
            :uid,
            :tipo,
            :titulo,
            :mensagem,
            0,
            NOW(),
            :link
        )
    ";

    $st = $conexao->prepare($sql);
    $st->bindValue(':uid',      $usuarioId, PDO::PARAM_INT);
    $st->bindValue(':tipo',     $tipo);
    $st->bindValue(':titulo',   $titulo);
    $st->bindValue(':mensagem', $mensagem);
    $st->bindValue(':link',     $link);

    $st->execute();
}
