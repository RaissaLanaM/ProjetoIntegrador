// js/home.js

document.addEventListener("DOMContentLoaded", () => {
  // Seleciona todos os botões dentro de elementos com classe .card
  const buttons = document.querySelectorAll(".card button");
  if (!buttons.length) return; // Se não tiver nenhum, não faz nada

  buttons.forEach((btn) => {
    btn.addEventListener("click", () => {
      // Se quiser personalizar no HTML, pode usar data-mensagem
      const customMessage = btn.getAttribute("data-mensagem");

      alert(
        customMessage ||
        "Em breve, você poderá ver os detalhes do item!"
      );
    });
  });
});
