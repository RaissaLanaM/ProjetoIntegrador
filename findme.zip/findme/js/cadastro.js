// js/cadastro.js

document.addEventListener("DOMContentLoaded", () => {
    const form = document.querySelector("form");
    if (!form) return;

    const inputs = form.querySelectorAll("input");

    form.addEventListener("submit", (e) => {
        let hasEmpty = false;

        inputs.forEach(input => {
            const value = input.value.trim();

            // Reseta estilos
            input.classList.remove("erro");

            if (value === "") {
                hasEmpty = true;
                input.classList.add("erro");
            }
        });

        if (hasEmpty) {
            e.preventDefault();
            alert("Por favor, preencha todos os campos.");
            return;
        }

        // Opcional — UX melhor
        alert("Cadastro enviado com sucesso!");
    });
});
