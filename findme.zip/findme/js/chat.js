// chat.js

// Referências globais para evitar ficar buscando no DOM toda hora
let chatInput = null;
let chatBox  = null;

/**
 * Inicializa referências do chat ao carregar a página.
 * Você pode chamar essa função no DOMContentLoaded
 * ou simplesmente deixar como está que funciona junto com sendMessage.
 */
function initChatRefs() {
  if (!chatInput) {
    chatInput = document.getElementById("message-input");
  }
  if (!chatBox) {
    chatBox = document.getElementById("chat-box");
  }
}

/**
 * Envia a mensagem visualmente no chat.
 * Pode ser usado no onsubmit do formulário:
 * <form onsubmit="sendMessage(event)">
 */
function sendMessage(event) {
  if (event && typeof event.preventDefault === "function") {
    event.preventDefault(); // Impede o envio tradicional do formulário
  }

  initChatRefs();

  if (!chatInput || !chatBox) {
    console.warn("Elementos do chat não encontrados (message-input / chat-box).");
    return;
  }

  const message = chatInput.value.trim();
  if (!message) {
    return;
  }

  // Cria um novo elemento para a mensagem
  const msgDiv = document.createElement("div");
  msgDiv.classList.add("message", "right");
  msgDiv.textContent = message;

  // Adiciona na caixa de chat
  chatBox.appendChild(msgDiv);
  chatBox.scrollTop = chatBox.scrollHeight;

  // Limpa o campo de input
  chatInput.value = "";
}

// Opcional: se existir um form com id="chat-form", conecta automaticamente
document.addEventListener("DOMContentLoaded", () => {
  initChatRefs();

  const form = document.getElementById("chat-form");
  if (form) {
    form.addEventListener("submit", sendMessage);
  }
});
