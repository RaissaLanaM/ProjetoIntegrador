

document.addEventListener('DOMContentLoaded', () => {
    const container = document.querySelector('.login-container');
    if (container) {
        // Estado inicial
        container.style.opacity = '0';
        container.style.transform = 'translateY(-20px)';

        // Animação suave de entrada
        setTimeout(() => {
            container.style.transition = 'all 0.6s ease';
            container.style.opacity = '1';
            container.style.transform = 'translateY(0)';
        }, 100);
    }

    // Inputs dentro da área de login
    const inputs = document.querySelectorAll('.login-container input');

    inputs.forEach((input) => {
        input.addEventListener('focus', () => {
            input.style.borderColor = '#4c83ff';
            input.style.boxShadow = '0 0 5px rgba(76, 131, 255, 0.5)';
            input.style.outline = 'none';
        });

        input.addEventListener('blur', () => {
            input.style.borderColor = '#ccc';
            input.style.boxShadow = 'none';
        });
    });

    // Botão principal de login
    const button = document.querySelector('.login-container button');

    if (button) {
        button.addEventListener('click', () => {
            button.style.transform = 'scale(0.98)';
            button.style.transition = 'transform 0.15s ease';

            setTimeout(() => {
                button.style.transform = 'scale(1)';
            }, 150);
        });
    }
});
