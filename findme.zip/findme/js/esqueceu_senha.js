// js/esqueceu_senha.js

document.addEventListener("DOMContentLoaded", () => {
    const form      = document.getElementById("formRecuperacao");
    const mensagem  = document.getElementById("mensagem");
    const emailInput = document.getElementById("email");

    if (!form || !mensagem || !emailInput) return;

    let msgTimeoutId = null;

    form.addEventListener("submit", (e) => {
        e.preventDefault(); // Evita o envio real do formulário (simulação)

        const email = emailInput.value.trim();

        // Reseta estado visual
        mensagem.textContent = "";
        mensagem.classList.remove("msg-erro", "msg-sucesso");

        // Validação simples de e-mail
        if (!email) {
            mensagem.classList.add("msg-erro");
            mensagem.textContent = "Por favor, informe seu e-mail cadastrado.";
            return;
        }

        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(email)) {
            mensagem.classList.add("msg-erro");
            mensagem.textContent = "Digite um e-mail válido.";
            return;
        }

        // Simulação de envio (em breve conecta com PHP)
        mensagem.classList.add("msg-sucesso");
        mensagem.textContent = "Se houver uma conta com esse e-mail, você receberá um link de redefinição.";

        // Limpa mensagem após alguns segundos
        if (msgTimeoutId) {
            clearTimeout(msgTimeoutId);
        }
        msgTimeoutId = setTimeout(() => {
            mensagem.textContent = "";
            mensagem.classList.remove("msg-erro", "msg-sucesso");
        }, 5000);

        // Limpa o campo
        form.reset();
    });
});
