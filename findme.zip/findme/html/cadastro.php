<?php
session_start();
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Cadastro - FindMe</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Fonte Google -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/header.css">

    <!-- CSS -->
    <link rel="stylesheet" href="../assets/css/cadastro.css">
</head>
<body>
    <main class="main-content">
        <div class="cadastro-container">
            <h1>Cadastro de Usuário</h1>

            <!-- Mensagens de erro -->
            <?php if (!empty($_SESSION['mensagem_erro'])): ?>
                <div class="msg-erro" role="alert" aria-live="assertive">
                    <?= htmlspecialchars($_SESSION['mensagem_erro'], ENT_QUOTES, 'UTF-8'); ?>
                </div>
                <?php unset($_SESSION['mensagem_erro']); ?>
            <?php endif; ?>

            <!-- Mensagens de sucesso -->
            <?php if (!empty($_SESSION['mensagem_sucesso'])): ?>
                <div class="msg-sucesso" role="status" aria-live="polite">
                    <?= htmlspecialchars($_SESSION['mensagem_sucesso'], ENT_QUOTES, 'UTF-8'); ?>
                </div>
                <?php unset($_SESSION['mensagem_sucesso']); ?>
            <?php endif; ?>

            <p class="subtitulo">Preencha os dados para criar sua conta</p>

            <form 
                action="../php/processar_cadastro.php" 
                method="POST" 
                class="cadastro-form"
                autocomplete="on"
            >
                <label for="nome">Nome</label>
                <input
                    type="text"
                    name="nome"
                    id="nome"
                    placeholder="Digite seu nome completo"
                    required
                >

                <label for="email">E-mail</label>
                <input
                    type="email"
                    name="email"
                    id="email"
                    placeholder="Digite seu e-mail"
                    required
                >

                <label for="senha">Senha</label>
                <input
                    type="password"
                    name="senha"
                    id="senha"
                    placeholder="Crie uma senha"
                    required
                >

                <label for="confirmar">Confirmar Senha</label>
                <input
                    type="password"
                    name="confirmar"
                    id="confirmar"
                    placeholder="Repita sua senha"
                    required
                >

                <button type="submit" class="btn-cadastro">Cadastrar</button>
            </form>

            <p class="login-link">
                Já tem uma conta? <a href="login.php">Faça login</a>
            </p>
        </div>
    </main>

    <?php include_once '../includes/footer.php'; ?>
</body>
</html>
