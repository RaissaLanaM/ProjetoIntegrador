<?php
session_start();

/**
 * Página inicial do sistema FindMe.
 * 
 * Exibe opções diferentes para visitantes e usuários logados.
 */
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>FindMe - Achados e Perdidos</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="FindMe - Sistema de Achados e Perdidos para facilitar a devolução de objetos em cidades inteligentes.">

    <!-- Fonte Poppins -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;700&display=swap" rel="stylesheet">

    <!-- CSS exclusivo da página inicial -->
    <link rel="stylesheet" href="../assets/css/index.css?v=3">
</head>
<body>
    <main class="main-content">
        <section class="index-container" aria-labelledby="titulo-principal">
            <h1 id="titulo-principal">
                Bem-vindo ao <span>FindMe</span> 👋
            </h1>

            <?php if (!empty($_SESSION['usuario_nome'])): ?>
                <!-- Usuário logado -->
                <p class="descricao">
                    Olá,
                    <strong><?= htmlspecialchars($_SESSION['usuario_nome'], ENT_QUOTES, 'UTF-8'); ?></strong>!  
                    Aproveite para cadastrar novos objetos ou procurar por itens perdidos.
                </p>

                <div class="botoes" aria-label="Ações rápidas">
                    <a href="criar_objeto.php" class="btn">📦 Cadastrar Objeto</a>
                    <a href="listar_objetos.php" class="btn btn-secundario">🔍 Procurar Objeto</a>
                    <a href="../php/logout.php" class="btn btn-sair">🚪 Sair</a>
                </div>
            <?php else: ?>
                <!-- Visitante -->
                <p class="descricao">
                    O <strong>FindMe</strong> é um sistema de achados e perdidos criado para facilitar a devolução de objetos em cidades inteligentes.
                </p>

                <p class="chamada">
                    Você perdeu ou encontrou algo? Escolha uma opção:
                </p>
                
                <div class="botoes" aria-label="Ações para começar a usar o sistema">
                    <a href="login.php" class="btn">🔑 Entrar</a>
                    <a href="cadastro.php" class="btn btn-secundario">📝 Criar Conta</a>
                </div>
            <?php endif; ?>
        </section>
    </main>

    <footer>
        <p>&copy; <?= date('Y'); ?> - Projeto TCC FindMe</p>
    </footer>
</body>
</html>
