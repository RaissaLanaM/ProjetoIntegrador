<?php
session_start();

/*
  Página de recuperação de senha
  Exibe mensagens vindas do backend e envia o e-mail para processar_recuperar.php
*/
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Recuperar Senha - FindMe</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Fonte -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;700&display=swap" rel="stylesheet">

    <!-- CSS -->
    <link rel="stylesheet" href="../assets/css/recuperar.css">
</head>
<body>
    <div class="main-content">
        <div class="recuperar-container">

            <h1>Recuperar Senha</h1>
            <p class="subtitulo">Digite o e-mail cadastrado para receber instruções de redefinição</p>

            <!-- Mensagens de retorno -->
            <?php if (!empty($_SESSION['mensagem_erro'])): ?>
                <div class="msg-erro" role="alert">
                    <?= htmlspecialchars($_SESSION['mensagem_erro']); ?>
                </div>
                <?php unset($_SESSION['mensagem_erro']); ?>
            <?php endif; ?>

            <?php if (!empty($_SESSION['mensagem_sucesso'])): ?>
                <div class="msg-sucesso" role="alert">
                    <?= htmlspecialchars($_SESSION['mensagem_sucesso']); ?>
                </div>
                <?php unset($_SESSION['mensagem_sucesso']); ?>
            <?php endif; ?>

            <!-- Formulário -->
            <form action="../php/processar_recuperar.php" method="POST" class="recuperar-form" autocomplete="off">
                
                <label for="email">E-mail cadastrado</label>
                <input 
                    type="email"
                    name="email"
                    id="email"
                    placeholder="seuemail@exemplo.com"
                    required
                    autofocus
                >

                <button type="submit" class="btn-recuperar">Enviar link de redefinição</button>
            </form>

            <p class="login-link">
                Lembrou da senha?  
                <a href="login.php">Voltar ao login</a>
            </p>
        </div>
    </div>

    <?php include_once('../includes/footer.php'); ?>
</body>
</html>
