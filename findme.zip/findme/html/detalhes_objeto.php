<?php
session_start();
require_once '../includes/conexao.php';

if (!isset($_SESSION['usuario_id'])) {
    header('Location: login.php');
    exit();
}

$usuarioLogado = (int) $_SESSION['usuario_id'];

// valida ID
if (!isset($_GET['id']) || !ctype_digit($_GET['id'])) {
    header('Location: perfil.php');
    exit();
}

$objetoId = (int) $_GET['id'];

/*
   Carrega o objeto + dono.

   AGORA: não restringe mais pelo usuário logado,
   qualquer usuário logado pode ver o detalhe.
*/
$sql = "
    SELECT 
        o.*,
        u.nome  AS nome_dono,
        u.email AS email_dono
    FROM objetos o
    JOIN usuarios u ON u.id = o.id_usuario
    WHERE o.id = :id
    LIMIT 1
";

$stmt = $conexao->prepare($sql);
$stmt->bindValue(':id',  $objetoId, PDO::PARAM_INT);
$stmt->execute();

$obj = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$obj) {
    // nada encontrado
    $_SESSION['mensagem_erro'] = 'Objeto não encontrado.';
    header('Location: perfil.php');
    exit();
}

function e($s) {
    return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8');
}

// informações de denúncia / risco
$denTotal  = (int) ($obj['denuncia_total']  ?? 0);
$denNivel  = (int) ($obj['denuncia_nivel']  ?? 0);
$denAvisar = (int) ($obj['denuncia_avisar'] ?? 0);

$mostrarAlerta = $denAvisar || $denNivel >= 3 || $denTotal >= 3;

// tipo do objeto (perdido/achado/devolvido)
$tipo = $obj['tipo_objeto'] ?? 'perdido';

// status badge
$badgeClasse = 'status-perdido';
$badgeTexto  = 'Perdido';

if ($tipo === 'achado') {
    $badgeClasse = 'status-achado';
    $badgeTexto  = 'Achado';
} elseif ($tipo === 'devolvido') {
    $badgeClasse = 'status-devolvido';
    $badgeTexto  = 'Devolvido';
}

// data bonitinha
$dataLabel = '';
if (!empty($obj['data_encontrado'])) {
    $ts = strtotime($obj['data_encontrado']);
    if ($ts) {
        $dataLabel = date('d/m/Y', $ts);
    }
}

// imagem
$imgSrc = null;
if (!empty($obj['imagem'])) {
    $imgSrc = '../uploads/objetos/' . $obj['imagem'];
}

// verifica se o objeto é do usuário logado (pra mostrar botões de editar/excluir)
$isMeuObjeto = ((int)$obj['id_usuario'] === $usuarioLogado);

/* ===========================================================
   CSRF TOKEN para exclusão
=========================================================== */
if (empty($_SESSION['csrf'])) {
    $_SESSION['csrf'] = bin2hex(random_bytes(32));
}
$csrfToken = $_SESSION['csrf'];
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="utf-8">
    <title>Detalhes do objeto — FindMe</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSS globais -->
    <link rel="stylesheet" href="../assets/css/header.css">
    <link rel="stylesheet" href="../assets/css/feed.css">
    
    <style>
        /* Estilo básico da página de detalhes – pode jogar para um .css depois */

        body {
            font-family: "Poppins", system-ui, -apple-system, Segoe UI, Roboto, Arial, sans-serif;
            margin: 0;
            background: linear-gradient(to bottom right,#dff0ff 0%,#eef6ff 60%,#ffffff 100%);
            color: #111827;
        }

        .detalhes-wrapper {
            max-width: 1100px;
            margin: 2rem auto 4rem;
            padding: 0 1rem;
        }

        .detalhes-topo h1 {
            font-size: 1.6rem;
            font-weight: 700;
            color: #1a3d6d;
            margin: 0 0 .25rem;
        }

        .detalhes-topo p {
            margin: 0 0 1.5rem;
            color: #4b5563;
            font-size: .95rem;
        }

        .card-objeto-detalhe {
            background: #ffffff;
            border-radius: 18px;
            border: 1px solid rgba(44,116,179,.08);
            box-shadow: 0 20px 40px rgba(28,64,134,.12),0 4px 10px rgba(0,0,0,.05);
            overflow: hidden;
            display: grid;
            grid-template-columns: minmax(260px, 360px) 1fr;
            gap: 1.5rem;
            padding: 1.25rem 1.5rem 1.5rem;
        }

        .card-objeto-detalhe.flagged-hard {
            border-color: rgba(217,48,37,.35);
        }

        .detalhe-img-wrapper {
            background:#f8faff;
            border-radius: 14px;
            display:flex;
            align-items:center;
            justify-content:center;
            overflow:hidden;
        }

        .detalhe-img-wrapper img {
            width:100%;
            height:100%;
            object-fit:cover;
            display:block;
        }

        .detalhe-img-placeholder {
            font-size:.9rem;
            color:#6b7280;
            font-style:italic;
            text-align:center;
            padding:2rem 1rem;
        }

        .detalhe-body {
            display:flex;
            flex-direction:column;
            gap:.75rem;
        }

        .detalhe-header-line {
            display:flex;
            align-items:center;
            justify-content:space-between;
            gap:.5rem;
        }

        .detalhe-titulo {
            font-size:1.3rem;
            font-weight:700;
            color:#1a3d6d;
        }

        .status-badge {
            padding:.35rem .8rem;
            border-radius:999px;
            font-size:.78rem;
            font-weight:700;
            color:#fff;
            box-shadow:0 8px 18px rgba(0,0,0,.12);
        }
        .status-perdido   { background:#d32f2f; }
        .status-achado    { background:#2e7d32; }
        .status-devolvido { background:#6d4c41; }

        .detalhe-descricao {
            font-size:.95rem;
            color:#374151;
            line-height:1.6;
        }

        .detalhe-info {
            font-size:.9rem;
            color:#111827;
        }
        .detalhe-info strong {
            color:#1a3d6d;
        }

        .detalhe-meta {
            display:grid;
            grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
            gap:.4rem .75rem;
            margin-top:.4rem;
        }

        .detalhe-rodape {
            margin-top:1rem;
            display:flex;
            flex-wrap:wrap;
            gap:.6rem;
        }

        .btn-primary,
        .btn-secondary,
        .btn-danger {
            display:inline-flex;
            align-items:center;
            justify-content:center;
            gap:.4rem;
            padding:.65rem 1.1rem;
            border-radius:999px;
            font-size:.9rem;
            font-weight:600;
            text-decoration:none;
            border:0;
            cursor:pointer;
            transition:transform .15s ease, box-shadow .2s ease, filter .2s ease;
        }

        .btn-primary {
            background:#2C74B3;
            color:#fff;
            box-shadow:0 14px 28px rgba(44,116,179,.26),0 4px 8px rgba(0,0,0,.08);
        }
        .btn-primary:hover { transform:translateY(-1px); filter:brightness(1.03); }

        .btn-secondary {
            background:#f3f4f6;
            color:#111827;
            box-shadow:0 6px 12px rgba(0,0,0,.06);
        }

        .btn-danger {
            background:#d93025;
            color:#fff;
            box-shadow:0 10px 22px rgba(217,48,37,.22);
        }

        .alert-risco {
            margin:0 0 1rem;
            padding:.9rem 1rem;
            border-radius:12px;
            background:linear-gradient(180deg,#fff8e6 0%,#ffeab3 100%);
            color:#7a4c00;
            border:1px solid #ffd789;
            font-size:.9rem;
            font-weight:600;
        }

        .link-voltar {
            display:inline-flex;
            align-items:center;
            margin-top:1.25rem;
            font-size:.9rem;
            color:#1a3d6d;
            text-decoration:none;
            font-weight:500;
        }
        .link-voltar:hover { text-decoration:underline; }

        @media (max-width: 768px) {
            .card-objeto-detalhe {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body class="fm-body fm-has-sticky-header">
<?php include '../includes/header.php'; ?>

<main class="detalhes-wrapper">
    <div class="detalhes-topo">
        <h1>Detalhes do objeto</h1>
        <p>Veja as informações completas do anúncio selecionado.</p>
    </div>

    <section class="card-objeto-detalhe <?= $mostrarAlerta ? 'flagged-hard' : ''; ?>">
        <div class="detalhe-img-wrapper">
            <?php if ($imgSrc): ?>
                <img src="<?= e($imgSrc); ?>" alt="<?= e($obj['titulo']); ?>">
            <?php else: ?>
                <div class="detalhe-img-placeholder">
                    Sem imagem enviada para este anúncio.
                </div>
            <?php endif; ?>
        </div>

        <div class="detalhe-body">
            <div class="detalhe-header-line">
                <div class="detalhe-titulo">
                    <?= e($obj['titulo']); ?>
                </div>
                <span class="status-badge <?= $badgeClasse; ?>">
                    <?= e($badgeTexto); ?>
                </span>
            </div>

            <?php if ($mostrarAlerta): ?>
                <div class="alert-risco">
                    Este anúncio recebeu <?= $denTotal; ?> denúncias (risco <?= $denNivel; ?>).
                    Cuidado e verifique as informações antes de prosseguir.
                </div>
            <?php endif; ?>

            <?php if (!empty($obj['descricao'])): ?>
                <p class="detalhe-descricao">
                    <?= nl2br(e($obj['descricao'])); ?>
                </p>
            <?php endif; ?>

            <div class="detalhe-meta">
                <?php if (!empty($obj['categoria'])): ?>
                    <div class="detalhe-info">
                        <strong>Categoria:</strong> <?= e($obj['categoria']); ?>
                    </div>
                <?php endif; ?>

                <?php if (!empty($obj['local_encontrado'])): ?>
                    <div class="detalhe-info">
                        <strong>Local:</strong> <?= e($obj['local_encontrado']); ?>
                    </div>
                <?php endif; ?>

                <?php if ($dataLabel): ?>
                    <div class="detalhe-info">
                        <strong>Data:</strong> <?= e($dataLabel); ?>
                    </div>
                <?php endif; ?>

                <div class="detalhe-info">
                    <strong>Cadastrado por:</strong> <?= e($obj['nome_dono']); ?>
                </div>
            </div>

            <div class="detalhe-rodape">
                <?php if ($isMeuObjeto): ?>
                    <a href="editar_objeto.php?id=<?= (int)$obj['id']; ?>" class="btn-primary">
                        ✏️ Editar anúncio
                    </a>

                    <form action="../php/excluir_objeto.php" method="post"
                          onsubmit="return confirm('Tem certeza que deseja excluir este anúncio?');">
                        <input type="hidden" name="id" value="<?= (int)$obj['id']; ?>">
                        <!-- CSRF token -->
                        <input type="hidden" name="csrf" value="<?= e($csrfToken); ?>">
                        <button type="submit" class="btn-danger">
                            🗑️ Excluir anúncio
                        </button>
                    </form>
                <?php endif; ?>

                <a href="perfil.php" class="btn-secondary">
                    ⬅ Voltar ao perfil
                </a>
            </div>
        </div>
    </section>

    <a href="perfil.php" class="link-voltar">← Voltar para Meu Perfil</a>
</main>

<?php include '../includes/footer.php'; ?>
</body>
</html>
