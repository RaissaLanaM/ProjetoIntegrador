<?php
// /html/esqueci_senha.php
session_start();
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Recuperar Senha - FindMe</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Fonte e CSS -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/header.css">
    <link rel="stylesheet" href="../assets/css/form_base.css">
    <style>
        /* Caso não exista form_base.css no seu projeto */
        .form-container {
            max-width: 420px;
            margin: 40px auto;
            padding: 25px 30px;
            background: #fff;
            border-radius: 14px;
            box-shadow: 0 3px 12px rgba(0,0,0,0.08);
            font-family: 'Poppins', sans-serif;
        }
        .form-container h2 {
            text-align: center;
            margin-bottom: 15px;
            font-size: 1.6rem;
        }
        .form-container label {
            font-weight: 500;
        }
        .form-container input[type="email"],
        .form-container input[type="password"],
        .form-container input[type="text"] {
            width: 100%;
            padding: 10px 12px;
            margin: 6px 0 15px;
            border-radius: 8px;
            border: 1px solid #c9d3e0;
            outline: none;
            font-size: 0.95rem;
        }
        .form-container input[type="submit"] {
            width: 100%;
            padding: 12px;
            background: #4A7CFF;
            border: none;
            border-radius: 8px;
            color: #fff;
            font-size: 1rem;
            font-weight: 600;
            cursor: pointer;
            margin-top: 5px;
        }
        .form-container input[type="submit"]:hover {
            background: #3a64d9;
        }
        .link-voltar {
            margin-top: 15px;
            text-align: center;
            display: block;
            color: #4A7CFF;
            font-weight: 500;
        }
    </style>
</head>

<body>
<?php include_once('../includes/header.php'); ?>

<main>
    <div class="form-container">
        <h2>Recuperar Senha</h2>

        <?php if (!empty($_SESSION['mensagem_erro'])): ?>
            <div class="msg-erro" style="margin-bottom:10px;">
                <?= htmlspecialchars($_SESSION['mensagem_erro'], ENT_QUOTES, 'UTF-8'); ?>
            </div>
            <?php unset($_SESSION['mensagem_erro']); ?>
        <?php endif; ?>

        <?php if (!empty($_SESSION['mensagem_sucesso'])): ?>
            <div class="msg-sucesso" style="margin-bottom:10px;">
                <?= htmlspecialchars($_SESSION['mensagem_sucesso'], ENT_QUOTES, 'UTF-8'); ?>
            </div>
            <?php unset($_SESSION['mensagem_sucesso']); ?>
        <?php endif; ?>

        <form action="../php/processar_esqueci_senha.php" method="POST">
            <label for="email">Digite seu e-mail cadastrado:</label>
            <input
                type="email"
                name="email"
                id="email"
                required
                autocomplete="email"
                placeholder="exemplo@findme.com"
            >

            <input type="submit" value="Enviar link de redefinição">
        </form>

        <a class="link-voltar" href="login.php">← Voltar ao login</a>
    </div>
</main>

<?php include_once('../includes/footer.php'); ?>
</body>
</html>
