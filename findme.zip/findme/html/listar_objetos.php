<?php
session_start();
require_once '../includes/conexao.php';

/**
 * Listagem de objetos com filtros e paginação.
 * 
 * Filtros:
 * - q        → termo de busca (título, descrição, categoria, local)
 * - tipo     → achado | perdido | (vazio = todos)
 * - categoria
 * - dt_ini   → data inicial
 * - dt_fim   → data final
 * - ord      → recentes | antigos | titulo
 */

if (!isset($_SESSION['usuario_id'])) {
    header('Location: login.php');
    exit();
}

$usuarioLogado = (int) $_SESSION['usuario_id'];

/* ========= filtros ========= */
$q      = trim($_GET['q'] ?? '');
$tipo   = $_GET['tipo'] ?? ''; // 'achado' | 'perdido' | ''
$categ  = trim($_GET['categoria'] ?? '');
$dt_ini = $_GET['dt_ini'] ?? '';
$dt_fim = $_GET['dt_fim'] ?? '';
$ord    = $_GET['ord'] ?? 'recentes';

$por_pagina = 12;
$pagina     = max(1, (int) ($_GET['p'] ?? 1));
$offset     = ($pagina - 1) * $por_pagina;

$where = [];

/* ===== monta WHERE dinamicamente (sem placeholders) ===== */

if ($q !== '') {
    $qLike = $conexao->quote('%' . $q . '%');
    $where[] = "(o.titulo LIKE $qLike 
                 OR o.descricao LIKE $qLike 
                 OR o.categoria LIKE $qLike 
                 OR o.local_encontrado LIKE $qLike)";
}

if ($tipo === 'achado' || $tipo === 'perdido') {
    $tipoEsc = $conexao->quote($tipo);
    $where[] = "o.tipo_objeto = $tipoEsc";
}

if ($categ !== '') {
    $catLike = $conexao->quote('%' . $categ . '%');
    $where[] = "o.categoria LIKE $catLike";
}

if ($dt_ini !== '') {
    $diniEsc = $conexao->quote($dt_ini);
    $where[] = "o.data_encontrado >= $diniEsc";
}

if ($dt_fim !== '') {
    $dfimEsc = $conexao->quote($dt_fim);
    $where[] = "o.data_encontrado <= $dfimEsc";
}

$where_sql = $where ? 'WHERE ' . implode(' AND ', $where) : '';

/* ===== ordenação ===== */
switch ($ord) {
    case 'antigos':
        $order_sql = 'ORDER BY o.data_encontrado ASC, o.id DESC';
        break;
    case 'titulo':
        $order_sql = 'ORDER BY o.titulo ASC';
        break;
    default:
        $order_sql = 'ORDER BY o.data_encontrado DESC, o.id DESC';
}

/* ===== total de registros ===== */
$sqlCount = "SELECT COUNT(*) FROM objetos o $where_sql";
$stmtC    = $conexao->query($sqlCount);
$total    = (int) $stmtC->fetchColumn();
$paginas  = max(1, (int) ceil($total / $por_pagina));

/* ===== consulta principal ===== */
$lim = (int) $por_pagina;
$off = (int) $offset;

$sql = "
  SELECT 
      o.id, 
      o.titulo, 
      o.tipo_objeto, 
      o.categoria, 
      o.local_encontrado, 
      o.data_encontrado,
      o.imagem, 
      o.id_usuario, 
      u.nome AS dono
  FROM objetos o
  LEFT JOIN usuarios u ON u.id = o.id_usuario
  $where_sql
  $order_sql
  LIMIT $lim OFFSET $off
";

$stmt = $conexao->query($sql);
$rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

/**
 * Mantém os parâmetros atuais de GET e sobrescreve apenas o que vier em $extra.
 */
function keep(array $extra = []): string
{
    return '?' . http_build_query(array_merge($_GET, $extra));
}

/**
 * Helper de escape.
 */
function e($s): string
{
    return htmlspecialchars((string) $s, ENT_QUOTES, 'UTF-8');
}
?>
<!doctype html>
<html lang="pt-BR">
<head>
  <meta charset="utf-8">
  <title>Objetos — FindMe</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <!-- Fonte e CSS -->
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="../assets/css/header.css">
  <link rel="stylesheet" href="../assets/css/listar_objetos.css">
</head>
<body>
<?php include '../includes/header.php'; ?>

<div class="listar-wrapper">
  <h1 class="page-title">Objetos</h1>

  <!-- filtros -->
  <form class="filters" action="" method="get">
    <!-- busca -->
    <div>
      <label for="q">Buscar</label>
      <input
        id="q"
        name="q"
        type="text"
        placeholder="Título, descrição, local, categoria…"
        value="<?= e($q); ?>"
      >
    </div>

    <!-- tipo -->
    <div>
      <label for="tipo">Tipo</label>
      <select id="tipo" name="tipo">
        <option value="">Todos</option>
        <option value="perdido" <?= $tipo === 'perdido' ? 'selected' : ''; ?>>Perdido</option>
        <option value="achado"  <?= $tipo === 'achado'  ? 'selected' : ''; ?>>Achado</option>
      </select>
    </div>

    <!-- ordenação -->
    <div>
      <label for="ord">Ordenar por</label>
      <select id="ord" name="ord">
        <option value="recentes" <?= $ord === 'recentes' ? 'selected' : ''; ?>>Mais recentes</option>
        <option value="antigos"  <?= $ord === 'antigos'  ? 'selected' : ''; ?>>Mais antigos</option>
        <option value="titulo"   <?= $ord === 'titulo'   ? 'selected' : ''; ?>>Título (A–Z)</option>
      </select>
    </div>

    <!-- linha 2 -->
    <div class="row" style="grid-column:1/-1;">
      <div>
        <label for="categoria">Categoria</label>
        <input
          id="categoria"
          name="categoria"
          type="text"
          placeholder="Ex.: carteira, chave, celular…"
          value="<?= e($categ); ?>"
        >
      </div>

      <div>
        <label for="dt_ini">De (data)</label>
        <input
          id="dt_ini"
          name="dt_ini"
          type="date"
          value="<?= e($dt_ini); ?>"
        >
      </div>

      <div>
        <label for="dt_fim">Até (data)</label>
        <input
          id="dt_fim"
          name="dt_fim"
          type="date"
          value="<?= e($dt_fim); ?>"
        >
      </div>

      <div class="filters-actions">
        <button
          class="btn btn-ghost"
          type="button"
          onclick="window.location='listar_objetos.php'"
        >
          Limpar
        </button>
        <button class="btn btn-primary" type="submit">
          Aplicar filtros
        </button>
      </div>
    </div>
  </form>

  <!-- grid -->
  <div class="grid">
    <?php if (!$rows): ?>
      <p style="grid-column:1/-1; text-align:center; color:#6b7280; font-weight:600; margin:22px 0;">
        Nenhum objeto encontrado.
      </p>
    <?php else: ?>
      <?php foreach ($rows as $r): ?>
        <?php
          $imgName = trim((string) ($r['imagem'] ?? ''));
          $imgPath = $imgName !== '' 
            ? "../uploads/objetos/" . $imgName 
            : "../assets/img/placeholder-item.png";

          $isMine   = ((int) $r['id_usuario'] === $usuarioLogado);
          $chipType = ($r['tipo_objeto'] === 'achado') ? 'type-achado' : 'type-perdido';
          $dono     = $r['dono'] ?: 'Anunciante';
        ?>
        <article class="card">
          <a
            class="thumb"
            href="#"
            style="background-image:url('<?= e($imgPath); ?>');"
            aria-label="Imagem do objeto"
          ></a>

          <div>
            <h3><?= e($r['titulo']); ?></h3>

            <div class="meta-line">
              <span class="chip <?= e($chipType); ?>">
                <?= e(ucfirst($r['tipo_objeto'])); ?>
              </span>

              <?php if (!empty($r['categoria'])): ?>
                <span class="chip">
                  Categoria: <?= e($r['categoria']); ?>
                </span>
              <?php endif; ?>
            </div>

            <div class="info">
              <?php if (!empty($r['local_encontrado'])): ?>
                <span title="Local">
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none">
                    <path d="M12 21s-7-4.35-7-10a7 7 0 1 1 14 0c0 5.65-7 10-7 10Z" stroke="#64748b" stroke-width="1.6"/>
                    <circle cx="12" cy="11" r="3" fill="#64748b"/>
                  </svg>
                  <?= e($r['local_encontrado']); ?>
                </span>
              <?php endif; ?>

              <?php if (!empty($r['data_encontrado'])): ?>
                <span title="Data">
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none">
                    <path d="M7 3v3M17 3v3M4 8h16M5 21h14a1 1 0 0 0 1-1V8H4v12a1 1 0 0 0 1 1Z" stroke="#64748b" stroke-width="1.6"/>
                  </svg>
                  <?= e(date('d/m/Y', strtotime($r['data_encontrado']))); ?>
                </span>
              <?php endif; ?>
            </div>

            <div class="actions">
              <?php if ($isMine): ?>
                <button class="btn-chat" type="button" disabled>
                  Seu anúncio
                </button>
              <?php else: ?>
                <a
                  class="btn-chat"
                  href="<?= '../php/iniciar_chat.php?id_dono=' . (int) $r['id_usuario']; ?>"
                >
                  Conversar com <?= e($dono); ?>
                </a>
              <?php endif; ?>
            </div>
          </div>
        </article>
      <?php endforeach; ?>
    <?php endif; ?>
  </div>

  <!-- paginação -->
  <?php if ($paginas > 1): ?>
    <nav class="pagination" aria-label="Paginação de resultados">
      <?php
        $ini = max(1, $pagina - 2);
        $fim = min($paginas, $pagina + 2);

        if ($ini > 1) {
            echo '<a class="page" href="' . e(keep(['p' => 1])) . '">&laquo;</a>';
        }
        if ($pagina > 1) {
            echo '<a class="page" href="' . e(keep(['p' => $pagina - 1])) . '">&lsaquo;</a>';
        }

        for ($p = $ini; $p <= $fim; $p++) {
            $cls = $p === $pagina ? 'page active' : 'page';
            echo '<a class="' . $cls . '" href="' . e(keep(['p' => $p])) . '">' . $p . '</a>';
        }

        if ($pagina < $paginas) {
            echo '<a class="page" href="' . e(keep(['p' => $pagina + 1])) . '">&rsaquo;</a>';
        }
        if ($fim < $paginas) {
            echo '<a class="page" href="' . e(keep(['p' => $paginas])) . '">&raquo;</a>';
        }
      ?>
    </nav>
  <?php endif; ?>

</div>

<?php include '../includes/footer.php'; ?>
</body>
</html>
