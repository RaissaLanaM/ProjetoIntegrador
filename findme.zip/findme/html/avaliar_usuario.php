<?php
session_start();
require_once '../includes/conexao.php';

if (!isset($_SESSION['usuario_id'])) {
    header('Location: login.php');
    exit();
}

$meuId = (int) $_SESSION['usuario_id'];
$paraId = isset($_GET['id']) ? (int) $_GET['id'] : 0;

if ($paraId <= 0 || $paraId === $meuId) {
    header('Location: perfil.php');
    exit();
}

// Carrega dados do usuário a ser avaliado
$stmt = $conexao->prepare("SELECT id, nome, email FROM usuarios WHERE id = :id LIMIT 1");
$stmt->bindValue(':id', $paraId, PDO::PARAM_INT);
$stmt->execute();
$alvo = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$alvo) {
    header('Location: perfil.php');
    exit();
}

// Verifica se já existe avaliação minha para essa pessoa
$stmt2 = $conexao->prepare("
    SELECT id, nota, comentario 
    FROM avaliacoes 
    WHERE de_usuario_id = :de AND para_usuario_id = :para 
    LIMIT 1
");
$stmt2->execute([
    ':de'   => $meuId,
    ':para'=> $paraId
]);
$avaliacaoExistente = $stmt2->fetch(PDO::FETCH_ASSOC);

function e($s) {
    return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8');
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="utf-8">
  <title>Avaliar usuário — FindMe</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <link rel="stylesheet" href="../assets/css/header.css">
  <link rel="stylesheet" href="../assets/css/perfil.css">
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;700&display=swap" rel="stylesheet">
</head>
<body>

<?php include '../includes/header.php'; ?>

<main class="perfil-main">
  <section class="perfil-card avaliacao-card">
    <h1>Avaliar usuário</h1>
    <p class="perfil-subtitle">
      Você está avaliando <strong><?= e($alvo['nome']); ?></strong>
    </p>

    <?php if ($avaliacaoExistente): ?>
      <div class="msg-erro">
        Você já avaliou este usuário com nota 
        <strong><?= (int)$avaliacaoExistente['nota']; ?>⭐</strong>.<br>
        Se precisar alterar sua avaliação, exclua manualmente no banco (para o TCC está ok assim 😉).
      </div>
      <a href="perfil.php?id=<?= (int)$paraId; ?>" class="btn-voltar-perfil">Voltar ao perfil</a>
    <?php else: ?>
      <?php if (!empty($_SESSION['mensagem_erro'])): ?>
        <div class="msg-erro"><?= $_SESSION['mensagem_erro']; unset($_SESSION['mensagem_erro']); ?></div>
      <?php endif; ?>

      <form action="../php/salvar_avaliacao.php" method="POST" class="perfil-form">
        <input type="hidden" name="para_usuario_id" value="<?= (int)$paraId; ?>">

        <label for="nota">Nota (1 a 5)</label>
        <select name="nota" id="nota" required>
          <option value="" disabled selected>Selecione...</option>
          <option value="1">1 ⭐ - experiência ruim</option>
          <option value="2">2 ⭐⭐</option>
          <option value="3">3 ⭐⭐⭐</option>
          <option value="4">4 ⭐⭐⭐⭐</option>
          <option value="5">5 ⭐⭐⭐⭐⭐ - ótima experiência</option>
        </select>

        <label for="comentario">Comentário (opcional)</label>
        <textarea name="comentario" id="comentario" rows="4" placeholder="Descreva como foi a experiência de contato, devolução etc."></textarea>

        <button type="submit" class="btn-principal">Enviar avaliação</button>
      </form>

      <a href="perfil.php?id=<?= (int)$paraId; ?>" class="btn-voltar-perfil">Cancelar e voltar ao perfil</a>
    <?php endif; ?>
  </section>
</main>

<?php include '../includes/footer.php'; ?>
</body>
</html>
