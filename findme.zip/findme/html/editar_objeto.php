<?php
session_start();
require_once '../includes/conexao.php';

/**
 * Tela de edição de objeto.
 * 
 * Regras:
 * - Apenas usuários logados podem acessar;
 * - Apenas o usuário que cadastrou o objeto pode editá-lo.
 */

// Verifica se o usuário está logado
if (!isset($_SESSION['usuario_id'])) {
    header('Location: login.php');
    exit();
}

$usuarioId = (int) $_SESSION['usuario_id'];

// Valida ID recebido por GET
if (!isset($_GET['id']) || !ctype_digit($_GET['id'])) {
    $_SESSION['mensagem_erro'] = 'Objeto inválido para edição.';
    header('Location: dashboard.php');
    exit();
}

$id = (int) $_GET['id'];

// Busca objeto no banco
$stmt = $conexao->prepare('SELECT * FROM objetos WHERE id = :id LIMIT 1');
$stmt->bindValue(':id', $id, PDO::PARAM_INT);
$stmt->execute();
$obj = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$obj) {
    $_SESSION['mensagem_erro'] = 'Objeto não encontrado.';
    header('Location: dashboard.php');
    exit();
}

// Verifica se o objeto pertence ao usuário logado
if ((int) $obj['id_usuario'] !== $usuarioId) {
    $_SESSION['mensagem_erro'] = 'Você não pode editar este objeto.';
    header('Location: dashboard.php');
    exit();
}

/**
 * Helper para escapar HTML com segurança.
 */
function e($s) {
    return htmlspecialchars((string) $s, ENT_QUOTES, 'UTF-8');
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="utf-8">
    <title>Editar Objeto - FindMe</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Fonte e CSS -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/header.css">
    <link rel="stylesheet" href="../assets/css/criar_objeto.css">
</head>
<body>
<?php include '../includes/header.php'; ?>

<main class="form-container">
    <h2>Editar Objeto</h2>
    <p class="descricao-form">Atualize as informações e salve para manter o anúncio sempre correto.</p>

    <form
        action="../php/atualizar_objeto.php"
        method="POST"
        enctype="multipart/form-data"
        autocomplete="on"
    >
        <input type="hidden" name="id" value="<?= (int) $obj['id']; ?>">

        <label for="tipo_objeto">Tipo:</label>
        <select name="tipo_objeto" id="tipo_objeto" required>
            <option value="achado"    <?= $obj['tipo_objeto'] === 'achado'    ? 'selected' : ''; ?>>Achado</option>
            <option value="perdido"   <?= $obj['tipo_objeto'] === 'perdido'   ? 'selected' : ''; ?>>Perdido</option>
            <option value="devolvido" <?= $obj['tipo_objeto'] === 'devolvido' ? 'selected' : ''; ?>>Devolvido</option>
        </select>

        <label for="titulo">Título:</label>
        <input
            type="text"
            name="titulo"
            id="titulo"
            value="<?= e($obj['titulo']); ?>"
            required
            minlength="3"
            maxlength="100"
        >

        <label for="descricao">Descrição:</label>
        <textarea
            name="descricao"
            id="descricao"
            required
            minlength="5"
            maxlength="1000"
        ><?= e($obj['descricao']); ?></textarea>

        <label for="categoria">Categoria:</label>
        <input
            type="text"
            name="categoria"
            id="categoria"
            value="<?= e($obj['categoria']); ?>"
            required
            maxlength="50"
        >

        <label for="local_encontrado">Local:</label>
        <input
            type="text"
            name="local_encontrado"
            id="local_encontrado"
            value="<?= e($obj['local_encontrado']); ?>"
            required
            maxlength="255"
        >

        <label for="data_encontrado">Data:</label>
        <input
            type="date"
            name="data_encontrado"
            id="data_encontrado"
            value="<?= $obj['data_encontrado'] ? date('Y-m-d', strtotime($obj['data_encontrado'])) : ''; ?>"
            required
        >

        <label>Imagem atual:</label>
        <?php if (!empty($obj['imagem'])): ?>
            <img
                src="../uploads/objetos/<?= e($obj['imagem']); ?>"
                alt="Imagem atual do objeto"
                style="width:220px;border-radius:10px;display:block;margin-bottom:8px;"
            >
        <?php else: ?>
            <p style="color:#6b7a90">Sem imagem</p>
        <?php endif; ?>

        <label for="imagem">Trocar imagem (opcional):</label>
        <input
            type="file"
            name="imagem"
            id="imagem"
            accept="image/*"
        >

        <button type="submit" class="btn-cadastrar">
            Salvar alterações
        </button>
    </form>
</main>

<?php include '../includes/footer.php'; ?>
</body>
</html>
