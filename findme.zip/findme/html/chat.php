<?php
session_start();
require_once '../includes/conexao.php';

/**
 * Tela de chat entre dois usuários.
 */

// Garante que o usuário esteja logado
if (!isset($_SESSION['usuario_id'])) {
    header('Location: login.php');
    exit();
}
$usuarioLogado = (int) $_SESSION['usuario_id'];

// Valida o ID do chat
if (!isset($_GET['id']) || !ctype_digit($_GET['id'])) {
    header('Location: listar_chats.php');
    exit();
}
$chat_id = (int) $_GET['id'];

// Carrega dados do chat e valida participação do usuário
$sqlChat = "
    SELECT 
        c.*,
        u1.nome AS nome_u1,
        u2.nome AS nome_u2
    FROM chats c
    JOIN usuarios u1 ON u1.id = c.usuario1_id
    JOIN usuarios u2 ON u2.id = c.usuario2_id
    WHERE c.id = :cid
    LIMIT 1
";
$stmtChat = $conexao->prepare($sqlChat);
$stmtChat->bindValue(':cid', $chat_id, PDO::PARAM_INT);
$stmtChat->execute();
$chat = $stmtChat->fetch(PDO::FETCH_ASSOC);

if (
    !$chat || 
    ($chat['usuario1_id'] != $usuarioLogado && $chat['usuario2_id'] != $usuarioLogado)
) {
    header('Location: listar_chats.php');
    exit();
}

// Descobre quem é o outro participante
if ((int) $chat['usuario1_id'] === $usuarioLogado) {
    $outro_id   = (int) $chat['usuario2_id'];
    $outro_nome = $chat['nome_u2'];
} else {
    $outro_id   = (int) $chat['usuario1_id'];
    $outro_nome = $chat['nome_u1'];
}

// Carrega mensagens do chat em ordem cronológica
$sqlMensagens = "
    SELECT 
        m.*,
        u.nome AS nome_remetente
    FROM mensagens m
    JOIN usuarios u ON u.id = m.de_usuario_id
    WHERE m.chat_id = :cid
    ORDER BY m.id ASC
";
$stmtMsg = $conexao->prepare($sqlMensagens);
$stmtMsg->bindValue(':cid', $chat_id, PDO::PARAM_INT);
$stmtMsg->execute();
$mensagens = $stmtMsg->fetchAll(PDO::FETCH_ASSOC);

/**
 * Retorna a data no formato dd/mm/aaaa
 */
function dataLabel(string $dt): string
{
    $ts = strtotime($dt);
    return $ts ? date('d/m/Y', $ts) : '';
}

$lastId  = $mensagens ? (int) end($mensagens)['id'] : 0;
$lastDay = $mensagens ? dataLabel(end($mensagens)['data_envio']) : '';
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>
        Chat — <?= htmlspecialchars($outro_nome, ENT_QUOTES, 'UTF-8'); ?> | FindMe
    </title>
    <meta name="description" content="Converse com outros usuários no chat seguro do FindMe.">

    <!-- Fonte -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600&display=swap" rel="stylesheet">

    <!-- CSS global e do chat -->
    <link rel="stylesheet" href="../assets/css/header.css">
    <link rel="stylesheet" href="../assets/css/ct.css">
</head>
<body class="chat-body">

<?php include '../includes/header.php'; ?>

<main class="chat-main">
    <div id="chat" class="chat-shell --light-theme">

        <!-- Topo do chat -->
        <header class="chat__titlebar">
            <div class="chat__titlebar-main">
                <div class="chat__titlebar-left">
                    <div class="avatar" aria-hidden="true">
                        <span>
                            <?= strtoupper(mb_substr($outro_nome, 0, 1, 'UTF-8')); ?>
                        </span>
                    </div>
                    <div class="contact">
                        <strong class="name">
                            <?= htmlspecialchars($outro_nome, ENT_QUOTES, 'UTF-8'); ?>
                        </strong>
                        <small id="typingHint" class="status">
                            online • ativo agora
                        </small>
                    </div>
                </div>

                <div class="chat__titlebar-actions">
                    <a href="perfil.php?id=<?= (int)$outro_id; ?>" class="chat-header-btn">
                        Ver perfil
                    </a>
                    <a href="avaliar_usuario.php?id=<?= (int)$outro_id; ?>" class="chat-header-btn">
                        Avaliar
                    </a>
                </div>
            </div>

            <a 
                class="chat-back-link" 
                href="listar_chats.php" 
                aria-label="Voltar para a lista de conversas"
            >
                ← Voltar para a lista de chats
            </a>
        </header>

        <!-- Área de mensagens -->
        <section
            class="chat__conversation-board"
            id="chatScroll"
            data-last-id="<?= (int) $lastId; ?>"
            data-last-day="<?= htmlspecialchars($lastDay, ENT_QUOTES, 'UTF-8'); ?>"
            aria-label="Histórico de mensagens"
        >
            <?php
            $ultimoDia = null;

            if (!empty($mensagens)):
                foreach ($mensagens as $msg):
                    $diaAtual = dataLabel($msg['data_envio']);
                    if ($diaAtual !== $ultimoDia):
                        $ultimoDia = $diaAtual;
                        ?>
                        <div class="chat__day-sep">
                            <span><?= $ultimoDia; ?></span>
                        </div>
                        <?php
                    endif;

                    $mine = ((int) $msg['de_usuario_id'] === $usuarioLogado);
                    ?>
                    <div
                        class="chat__conversation-board__message-container<?= $mine ? ' reversed' : ''; ?>"
                        data-id="<?= (int) $msg['id']; ?>"
                    >
                        <div class="chat__conversation-board__message__person">
                            <div class="chat__conversation-board__message__person__avatar">
                                <div class="avatar small <?= $mine ? 'me' : 'them'; ?>">
                                    <span>
                                        <?php
                                        $nickBase = $mine ? 'Você' : $msg['nome_remetente'];
                                        echo strtoupper(mb_substr($nickBase, 0, 1, 'UTF-8'));
                                        ?>
                                    </span>
                                </div>
                            </div>
                            <span class="chat__conversation-board__message__person__nickname">
                                <?= $mine ? 'Você' : htmlspecialchars($msg['nome_remetente'], ENT_QUOTES, 'UTF-8'); ?>
                            </span>
                        </div>

                        <div class="chat__conversation-board__message__context">
                            <div class="chat__conversation-board__message__bubble">
                                <span>
                                    <?= nl2br(htmlspecialchars($msg['mensagem'], ENT_QUOTES, 'UTF-8')); ?>
                                </span>
                                <time class="bubble-time">
                                    <?= date('H:i', strtotime($msg['data_envio'])); ?>
                                </time>
                            </div>
                        </div>

                        <div class="chat__conversation-board__message__options"></div>
                    </div>
                    <?php
                endforeach;
            else:
                ?>
                <div class="chat__empty">
                    Nenhuma mensagem ainda. Envie a primeira!
                </div>
            <?php endif; ?>
        </section>

        <!-- Barra de envio -->
        <form class="chat__conversation-panel" id="sendForm" autocomplete="off">
            <div class="chat__conversation-panel__container">
                <input type="hidden" id="chatId" value="<?= (int) $chat_id; ?>">
                <input type="hidden" id="toId"   value="<?= (int) $outro_id; ?>">

                <label for="msgField" class="sr-only">Mensagem</label>
                <textarea
                    id="msgField"
                    class="chat__conversation-panel__input panel-item"
                    placeholder="Escreva uma mensagem..."
                    rows="1"
                    required
                    autofocus
                ></textarea>

                <button
                    class="chat__conversation-panel__button panel-item btn-icon send-message-button"
                    id="sendBtn"
                    type="submit"
                    disabled
                    title="Enviar mensagem"
                    aria-label="Enviar mensagem"
                >
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24">
                        <line x1="22" y1="2" x2="11" y2="13" />
                        <polygon points="22 2 15 22 11 13 2 9 22 2" />
                    </svg>
                </button>
            </div>
        </form>

    </div>
</main>

<?php include '../includes/footer.php'; ?>

<script>
'use strict';

/* ===== Referências no DOM ===== */
const scroller  = document.getElementById('chatScroll');
const textarea  = document.getElementById('msgField');
const form      = document.getElementById('sendForm');
const sendBtn   = document.getElementById('sendBtn');
const chatId    = document.getElementById('chatId').value;
const toId      = document.getElementById('toId').value;
const typingEl  = document.getElementById('typingHint');

let lastId  = parseInt(scroller.dataset.lastId || '0', 10);
let lastDay = scroller.dataset.lastDay || '';

let typingTimer = null;

/* ===== Helpers JS ===== */

function esc(str) {
  return String(str).replace(/[&<>"']/g, function (m) {
    return {
      '&': '&amp;',
      '<': '&lt;',
      '>': '&gt;',
      '"': '&quot;',
      "'": '&#39;'
    }[m];
  });
}

function nearBottom(el) {
  return (el.scrollHeight - el.scrollTop - el.clientHeight) < 64;
}

function addDaySeparator(day) {
  const sep = document.createElement('div');
  sep.className = 'chat__day-sep';
  sep.innerHTML = '<span>' + esc(day) + '</span>';
  scroller.appendChild(sep);
}

function autoResize() {
  textarea.style.height = 'auto';
  const styles = window.getComputedStyle(textarea);
  const lineHeight = parseFloat(styles.lineHeight) || 20;
  const paddingY = parseFloat(styles.paddingTop || 0) + parseFloat(styles.paddingBottom || 0);
  const maxRows = 6;

  const rows = Math.min(maxRows, Math.ceil((textarea.scrollHeight - paddingY) / lineHeight));
  textarea.style.height = (rows * lineHeight + paddingY) + 'px';
}

function toggleSend() {
  sendBtn.disabled = textarea.value.trim().length === 0;
}

/* ===== Ping de "digitando..." ===== */

function pingTyping() {
  clearTimeout(typingTimer);
  typingTimer = setTimeout(() => {
    fetch('../php/typing_ping.php', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({ chat_id: chatId })
    }).catch(() => {});
  }, 250);
}

/* ===== Eventos de entrada ===== */

textarea.addEventListener('input', () => {
  autoResize();
  toggleSend();
  pingTyping();
});

window.addEventListener('load', () => {
  autoResize();
  toggleSend();
});

textarea.addEventListener('keydown', (e) => {
  if (e.key === 'Enter' && !e.shiftKey) {
    e.preventDefault();
    form.requestSubmit();
  }
});

/* ===== Renderizar nova mensagem na tela ===== */

function renderMsg(m) {
  if (m.dayLabel && m.dayLabel !== lastDay) {
    addDaySeparator(m.dayLabel);
    lastDay = m.dayLabel;
  }

  const isMine = !!m.mine;
  const container = document.createElement('div');
  container.className = 'chat__conversation-board__message-container' + (isMine ? ' reversed' : '');
  container.dataset.id = m.id;

  const nick = isMine ? 'Você' : (m.nick || '');
  const avatarLetter = (m.avatar || nick || '?').charAt(0).toUpperCase();

  container.innerHTML = `
    <div class="chat__conversation-board__message__person">
      <div class="chat__conversation-board__message__person__avatar">
        <div class="avatar small ${isMine ? 'me' : 'them'}">
          <span>${esc(avatarLetter)}</span>
        </div>
      </div>
      <span class="chat__conversation-board__message__person__nickname">
        ${isMine ? 'Você' : esc(nick)}
      </span>
    </div>
    <div class="chat__conversation-board__message__context">
      <div class="chat__conversation-board__message__bubble">
        <span>${esc(m.text).replace(/\n/g, '<br>')}</span>
        <time class="bubble-time">${esc(m.time || '')}</time>
      </div>
    </div>
    <div class="chat__conversation-board__message__options"></div>
  `;

  const shouldStick = nearBottom(scroller);
  scroller.appendChild(container);

  if (shouldStick) {
    scroller.scrollTop = scroller.scrollHeight;
  }

  lastId = Math.max(lastId, m.id);
}

/* ===== Envio de mensagem via AJAX ===== */

form.addEventListener('submit', async (e) => {
  e.preventDefault();

  const text = textarea.value.trim();
  if (!text) return;

  sendBtn.disabled = true;

  try {
    const res = await fetch('../php/enviar_mensagem.php', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({
        chat_id: chatId,
        para_usuario_id: toId,
        mensagem: text
      })
    });

    if (!res.ok) {
      throw new Error('Erro na resposta do servidor.');
    }

    const data = await res.json();

    if (data.ok && data.message) {
  renderMsg(data.message);
  textarea.value = '';
  autoResize();
  toggleSend();
  textarea.focus();
} else {
  const msg = data.error || 'Não foi possível enviar a mensagem. Tente novamente.';
  alert(msg);
}

  } catch (error) {
    console.error(error);
    alert('Erro ao enviar mensagem. Verifique sua conexão e tente novamente.');
  } finally {
    sendBtn.disabled = false;
  }
});

/* ===== Polling para novas mensagens ===== */

async function poll() {
  try {
    const url = '../php/poll_mensagens.php?' + new URLSearchParams({
      chat_id: chatId,
      last_id: lastId
    }).toString();

    const res = await fetch(url, { cache: 'no-store' });

    if (!res.ok) {
      throw new Error('Erro na resposta do servidor.');
    }

    const data = await res.json();

    if (Array.isArray(data.messages)) {
      data.messages.forEach(renderMsg);
    }

    if (typingEl) {
      typingEl.textContent = data.typing ? 'digitando…' : 'online • ativo agora';
    }
  } catch (error) {
    console.error(error);
  }
}

setInterval(poll, 2500);

/* ===== Ajusta scroll inicial e foco ===== */
scroller.scrollTop = scroller.scrollHeight;
textarea.focus();
</script>

</body>
</html>
