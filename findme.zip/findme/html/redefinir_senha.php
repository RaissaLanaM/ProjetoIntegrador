<?php
session_start();

/**
 * Tela de redefinição de senha.
 * 
 * Acesso permitido apenas se a etapa de verificação (e-mail/token)
 * já foi concluída e a aplicação setou a variável de sessão
 * `usuario_reset`.
 */
if (empty($_SESSION['usuario_reset'])) {
    header('Location: recuperar_senha.php');
    exit();
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Redefinir Senha - FindMe</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Fonte -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;700&display=swap" rel="stylesheet">

    <!-- CSS -->
    <link rel="stylesheet" href="../assets/css/recuperar.css">
</head>
<body>
    <div class="main-content">
        <div class="recuperar-container">
            <h1>Redefinir Senha</h1>
            <p class="subtitulo">Digite sua nova senha abaixo</p>

            <!-- Mensagens -->
            <?php if (!empty($_SESSION['mensagem_erro'])): ?>
                <div class="msg-erro" role="alert">
                    <?= htmlspecialchars($_SESSION['mensagem_erro'], ENT_QUOTES, 'UTF-8'); ?>
                </div>
                <?php unset($_SESSION['mensagem_erro']); ?>
            <?php endif; ?>

            <form
                action="../php/processar_redefinir.php"
                method="POST"
                class="recuperar-form"
                autocomplete="off"
            >
                <label for="senha">Nova senha</label>
                <input
                    type="password"
                    name="senha"
                    id="senha"
                    placeholder="Digite sua nova senha"
                    required
                    minlength="6"
                    autocomplete="new-password"
                    autofocus
                >

                <label for="confirmar">Confirmar nova senha</label>
                <input
                    type="password"
                    name="confirmar"
                    id="confirmar"
                    placeholder="Confirme a nova senha"
                    required
                    minlength="6"
                    autocomplete="new-password"
                >

                <button type="submit" class="btn-recuperar">
                    Redefinir senha
                </button>
            </form>
        </div>
    </div>

    <?php include_once '../includes/footer.php'; ?>
</body>
</html>
