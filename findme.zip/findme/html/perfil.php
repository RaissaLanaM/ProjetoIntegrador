<?php
session_start();
require_once '../includes/conexao.php';

if (!isset($_SESSION['usuario_id'])) {
    header('Location: login.php');
    exit();
}

$usuarioLogado = (int) $_SESSION['usuario_id'];
$perfilId = isset($_GET['id']) ? (int) $_GET['id'] : $usuarioLogado;

// Carrega dados do usuário
$stmt = $conexao->prepare("SELECT id, nome, email FROM usuarios WHERE id = :id LIMIT 1");
$stmt->bindValue(':id', $perfilId, PDO::PARAM_INT);
$stmt->execute();
$usuario = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$usuario) {
    header('Location: dashboard.php');
    exit();
}

// Média de avaliações
$stmtMedia = $conexao->prepare("
    SELECT AVG(nota) AS media, COUNT(*) AS total
    FROM avaliacoes
    WHERE para_usuario_id = :id
");
$stmtMedia->bindValue(':id', $perfilId, PDO::PARAM_INT);
$stmtMedia->execute();
$stats = $stmtMedia->fetch(PDO::FETCH_ASSOC) ?: ['media' => null, 'total' => 0];

$media = $stats['media'] ? round($stats['media'], 1) : null;
$totalAval = (int) ($stats['total'] ?? 0);

// Últimas avaliações recebidas
$stmtAval = $conexao->prepare("
    SELECT a.nota, a.comentario, a.data_avaliacao, u.nome AS nome_avaliador
    FROM avaliacoes a
    JOIN usuarios u ON u.id = a.de_usuario_id
    WHERE a.para_usuario_id = :id
    ORDER BY a.data_avaliacao DESC
    LIMIT 5
");
$stmtAval->bindValue(':id', $perfilId, PDO::PARAM_INT);
$stmtAval->execute();
$avaliacoes = $stmtAval->fetchAll(PDO::FETCH_ASSOC);

// Objetos cadastrados pelo usuário
$stmtObj = $conexao->prepare("
    SELECT id, titulo, tipo_objeto, categoria, status, data_encontrado
    FROM objetos
    WHERE id_usuario = :id
    ORDER BY data_encontrado DESC, id DESC
");
$stmtObj->bindValue(':id', $perfilId, PDO::PARAM_INT);
$stmtObj->execute();
$objetos = $stmtObj->fetchAll(PDO::FETCH_ASSOC);

// Verifica se eu posso avaliar este perfil
$possoAvaliar = ($perfilId !== $usuarioLogado);

// Verifica se eu já avaliei
$jaAvaliei = false;
if ($possoAvaliar) {
    $stmtJa = $conexao->prepare("
        SELECT id FROM avaliacoes
        WHERE de_usuario_id = :de AND para_usuario_id = :para
        LIMIT 1
    ");
    $stmtJa->execute([
        ':de'   => $usuarioLogado,
        ':para' => $perfilId
    ]);
    $jaAvaliei = (bool) $stmtJa->fetchColumn();
}

function e($s) {
    return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8');
}

// função simples para desenhar as estrelas
function estrelas($media) {
    if ($media === null) return 'Sem avaliações ainda';
    $full = (int)floor($media);
    $out = '';
    for ($i=1; $i<=5; $i++) {
        $out .= $i <= $full ? '★' : '☆';
    }
    return $out . ' ' . number_format($media, 1, ',', '.') . '/5';
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="utf-8">
  <title>Perfil — <?= e($usuario['nome']); ?> | FindMe</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <link rel="stylesheet" href="../assets/css/header.css">
  <link rel="stylesheet" href="../assets/css/perfil.css">
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;700&display=swap" rel="stylesheet">
</head>
<body>

<?php include '../includes/header.php'; ?>

<main class="perfil-main">

  <!-- MENSAGENS GERAIS -->
  <?php if (!empty($_SESSION['mensagem_erro'])): ?>
    <div class="msg-erro"><?= $_SESSION['mensagem_erro']; unset($_SESSION['mensagem_erro']); ?></div>
  <?php endif; ?>

  <?php if (!empty($_SESSION['mensagem_sucesso'])): ?>
    <div class="msg-sucesso"><?= $_SESSION['mensagem_sucesso']; unset($_SESSION['mensagem_sucesso']); ?></div>
  <?php endif; ?>

  <!-- CARTÃO PRINCIPAL DO PERFIL -->
  <section class="perfil-card">
    <div class="perfil-header">
      <div class="perfil-avatar">
        <span><?= strtoupper(mb_substr($usuario['nome'], 0, 1, 'UTF-8')); ?></span>
      </div>
      <div class="perfil-info">
        <h1><?= e($usuario['nome']); ?></h1>
        <p class="perfil-email"><?= e($usuario['email']); ?></p>

        <p class="perfil-rating">
          <span class="estrelas">
            <?= estrelas($media); ?>
          </span>
          <?php if ($totalAval > 0): ?>
            <span class="perfil-rating-count">(<?= $totalAval; ?> avaliação<?= $totalAval > 1 ? 'es' : ''; ?>)</span>
          <?php endif; ?>
        </p>

        <?php if ($possoAvaliar): ?>
          <div class="perfil-actions">
            <?php if ($jaAvaliei): ?>
              <span class="perfil-ja-avaliou">Você já avaliou este usuário.</span>
            <?php else: ?>
              <a href="avaliar_usuario.php?id=<?= (int)$perfilId; ?>" class="btn-principal">
                ⭐ Avaliar este usuário
              </a>
            <?php endif; ?>
          </div>
        <?php endif; ?>
      </div>
    </div>
  </section>

  <!-- ÚLTIMAS AVALIAÇÕES -->
  <section class="perfil-card">
    <h2>Últimas avaliações recebidas</h2>

    <?php if (empty($avaliacoes)): ?>
      <p class="perfil-vazio">Ainda não há avaliações para este usuário.</p>
    <?php else: ?>
      <ul class="lista-avaliacoes">
        <?php foreach ($avaliacoes as $av): ?>
          <li class="avaliacao-item">
            <div class="avaliacao-topo">
              <span class="avaliacao-nota"><?= (int)$av['nota']; ?>⭐</span>
              <span class="avaliacao-autor">por <?= e($av['nome_avaliador']); ?></span>
              <span class="avaliacao-data">
                <?= date('d/m/Y H:i', strtotime($av['data_avaliacao'])); ?>
              </span>
            </div>
            <?php if (!empty($av['comentario'])): ?>
              <p class="avaliacao-comentario"><?= nl2br(e($av['comentario'])); ?></p>
            <?php endif; ?>
          </li>
        <?php endforeach; ?>
      </ul>
    <?php endif; ?>
  </section>

  <!-- OBJETOS CADASTRADOS -->
  <section class="perfil-card">
    <h2>Objetos cadastrados por <?= e($usuario['nome']); ?></h2>

    <?php if (empty($objetos)): ?>
      <p class="perfil-vazio">Este usuário ainda não cadastrou nenhum objeto.</p>
    <?php else: ?>
      <ul class="lista-objetos">
        <?php foreach ($objetos as $obj): ?>
          <li class="objeto-item">
            <div class="objeto-header">
              <h3><?= e($obj['titulo']); ?></h3>
              <span class="objeto-status objeto-status-<?= e($obj['status'] ?? ''); ?>">
                <?= e(ucfirst($obj['status'] ?? '')); ?>
              </span>
            </div>
            <p class="objeto-meta">
              Tipo: <strong><?= e($obj['tipo_objeto']); ?></strong> •
              Categoria: <strong><?= e($obj['categoria']); ?></strong>
            </p>
            <p class="objeto-meta">
              Data: <strong><?= e($obj['data_encontrado']); ?></strong>
            </p>
            <a href="detalhes_objeto.php?id=<?= (int)$obj['id']; ?>" class="objeto-link">
              Ver detalhes →
            </a>
          </li>
        <?php endforeach; ?>
      </ul>
    <?php endif; ?>
  </section>

</main>

<?php include '../includes/footer.php'; ?>
</body>
</html>
