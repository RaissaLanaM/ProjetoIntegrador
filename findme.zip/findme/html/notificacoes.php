<?php
session_start();
require_once '../includes/conexao.php';

if (!isset($_SESSION['usuario_id'])) {
    header('Location: login.php');
    exit();
}

$usuarioId = (int) ($_SESSION['usuario_id'] ?? 0);

// Busca notificações do usuário logado
$sql = "
    SELECT id, tipo, titulo, mensagem, lida, created_at, link_destino
    FROM notificacoes
    WHERE usuario_id = :uid
    ORDER BY created_at DESC
";
$stmt = $conexao->prepare($sql);
$stmt->bindValue(':uid', $usuarioId, PDO::PARAM_INT);
$stmt->execute();
$notificacoes = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Marca como lidas ao abrir a página
$upd = $conexao->prepare("
    UPDATE notificacoes 
    SET lida = 1 
    WHERE usuario_id = :uid AND lida = 0
");
$upd->bindValue(':uid', $usuarioId, PDO::PARAM_INT);
$upd->execute();

/* Helpers */
function e($s) {
    return htmlspecialchars((string) $s, ENT_QUOTES, 'UTF-8');
}
function dataLabel($dt) {
    $ts = strtotime($dt);
    return $ts ? date('d/m/Y H:i', $ts) : '';
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="utf-8">
    <title>Minhas notificações — FindMe</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="stylesheet" href="../assets/css/header.css">

    <style>
      :root {
        --fm-bg-grad-1: #e5f3fb;
        --fm-bg-grad-2: #d3ebf7;
        --fm-bg-grad-3: #cfe6f3;
        --fm-bg-grad-4: #dfeff9;
      }
      body {
        margin: 0;
        font-family: "Poppins", system-ui, -apple-system, Segoe UI, Roboto, Arial, sans-serif;
        background: linear-gradient(180deg,
          var(--fm-bg-grad-1) 0%,
          var(--fm-bg-grad-2) 35%,
          var(--fm-bg-grad-3) 70%,
          var(--fm-bg-grad-4) 100%
        );
        color: #14202b;
      }
      .fm-page {
        max-width: 1100px;
        margin: 96px auto 40px;
        padding: 0 16px 40px;
      }
      .fm-page h1 {
        font-size: 1.7rem;
        margin-bottom: .35rem;
        color: #102a43;
      }
      .fm-page p.fm-page-sub {
        margin-top: 0;
        margin-bottom: 1.5rem;
        color: #4b6275;
        font-size: .95rem;
      }

      .fm-notif-list {
        display: flex;
        flex-direction: column;
        gap: 14px;
      }
      .fm-notif-card {
        background: #ffffff;
        border-radius: 18px;
        padding: 16px 20px;
        box-shadow: 0 14px 32px rgba(15, 41, 90, .16);
        border: 1px solid rgba(44, 116, 179, .12);
        display: flex;
        align-items: flex-start;
        gap: 12px;
        text-decoration: none;
        color: inherit;
        transition: transform .12s ease, box-shadow .12s ease, border-color .12s ease;
      }
      .fm-notif-card:hover {
        transform: translateY(-1px);
        box-shadow: 0 18px 40px rgba(15, 41, 90, .20);
        border-color: rgba(44, 116, 179, .4);
      }
      .fm-notif-card.nao-lida {
        background: linear-gradient(135deg, #fff7f7 0%, #ffffff 35%);
      }

      .fm-notif-icon {
        width: 34px;
        height: 34px;
        border-radius: 50%;
        display: grid;
        place-items: center;
        background: #ffe2e0;
        color: #bf1650;
        flex-shrink: 0;
        font-size: 1rem;
      }
      .fm-notif-icon.tipo-chat       { background:#e3f2fd; color:#1565c0; }
      .fm-notif-icon.tipo-denuncia   { background:#ffebee; color:#c62828; }
      .fm-notif-icon.tipo-avaliacao  { background:#e8f5e9; color:#2e7d32; }

      .fm-notif-main {
        flex: 1;
        min-width: 0;
      }
      .fm-notif-title-row {
        display: flex;
        justify-content: space-between;
        gap: 8px;
        align-items: baseline;
        margin-bottom: 4px;
      }
      .fm-notif-title {
        font-weight: 700;
        font-size: .98rem;
        color: #12355b;
      }
      .fm-notif-date {
        font-size: .78rem;
        color: #718096;
        white-space: nowrap;
      }
      .fm-notif-tag {
        display: inline-flex;
        align-items: center;
        padding: 2px 8px;
        border-radius: 999px;
        font-size: .7rem;
        font-weight: 600;
        letter-spacing: .02em;
        margin-bottom: 4px;
      }
      .fm-notif-tag.denuncia {
        background: #ffebee;
        color: #c62828;
      }
      .fm-notif-tag.chat {
        background: #e3f2fd;
        color: #1565c0;
      }
      .fm-notif-tag.avaliacao {
        background: #e8f5e9;
        color: #2e7d32;
      }

      .fm-notif-text {
        font-size: .9rem;
        color: #334e68;
      }

      .fm-notif-empty {
        margin-top: 2rem;
        text-align: center;
        color: #6b7b8f;
        font-size: .95rem;
      }

      @media (max-width: 640px) {
        .fm-page { margin-top: 80px; }
        .fm-notif-card { padding: 14px 16px; }
      }
    </style>
</head>
<body>
<?php include '../includes/header.php'; ?>

<main class="fm-page">
    <h1>Minhas notificações</h1>
    <p class="fm-page-sub">
        Veja as últimas atualizações sobre chats, denúncias e avaliações.
    </p>

    <?php if (!$notificacoes): ?>
        <div class="fm-notif-empty">
            Você ainda não possui notificações.
        </div>
    <?php else: ?>
        <div class="fm-notif-list">
            <?php foreach ($notificacoes as $n): ?>
                <?php
                  $tipo   = $n['tipo'] ?? '';
                  $lida   = (int) ($n['lida'] ?? 0);
                  $titulo = $n['titulo'] ?? '';
                  $msg    = $n['mensagem'] ?? '';
                  $data   = dataLabel($n['created_at'] ?? '');
                  $link   = $n['link_destino'] ?: '#';

                  $icon = '!';
                  if     ($tipo === 'chat')      $icon = '💬';
                  elseif ($tipo === 'denuncia')  $icon = '⚠️';
                  elseif ($tipo === 'avaliacao') $icon = '⭐';

                  $iconClass = 'tipo-default';
                  if     ($tipo === 'chat')      $iconClass = 'tipo-chat';
                  elseif ($tipo === 'denuncia')  $iconClass = 'tipo-denuncia';
                  elseif ($tipo === 'avaliacao') $iconClass = 'tipo-avaliacao';
                ?>
                <a href="<?= e($link); ?>"
                   class="fm-notif-card <?= $lida ? 'lida' : 'nao-lida'; ?>">
                    <div class="fm-notif-icon <?= $iconClass; ?>">
                        <?= e($icon); ?>
                    </div>
                    <div class="fm-notif-main">
                        <div class="fm-notif-title-row">
                            <div class="fm-notif-title">
                                <?= e($titulo); ?>
                            </div>
                            <div class="fm-notif-date">
                                <?= e($data); ?>
                            </div>
                        </div>

                        <?php if ($tipo): ?>
                            <div class="fm-notif-tag <?= e($tipo); ?>">
                                <?= ucfirst($tipo); ?>
                            </div>
                        <?php endif; ?>

                        <div class="fm-notif-text">
                            <?= e($msg); ?>
                        </div>
                    </div>
                </a>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
</main>

</body>
</html>
