<?php
session_start();
require_once '../includes/conexao.php';

/**
 * Tela de cadastro de objeto (achado/perdido).
 * 
 * Apenas usuários logados podem acessar esta página.
 */

// Verifica se o usuário está logado
if (!isset($_SESSION['usuario_id'])) {
    header('Location: ../login.php');
    exit();
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Cadastrar Objeto - FindMe</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Fonte e CSS -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/header.css">
    <link rel="stylesheet" href="../assets/css/criar_objeto.css">
    

    <script>
        document.addEventListener('DOMContentLoaded', function () {
            const API_KEY = 'pk.c05462cc7e671486a0277a23512d1a90'; // LocationIQ
            const localInput = document.getElementById('local_encontrado');
            const latInput   = document.getElementById('latitude');
            const lonInput   = document.getElementById('longitude');

            if (!localInput || !latInput || !lonInput) {
                return; // se algum campo não existir, evita erro de JS
            }

            // placeholder inicial
            localInput.placeholder = 'Carregando localização...';

            if (!navigator.geolocation) {
                localInput.placeholder = 'Digite o local manualmente';
                return;
            }

            navigator.geolocation.getCurrentPosition(onSuccess, onError, {
                enableHighAccuracy: true,
                timeout: 10000,
                maximumAge: 0
            });

            function onSuccess(position) {
                const latitude  = position.coords.latitude;
                const longitude = position.coords.longitude;

                latInput.value = latitude;
                lonInput.value = longitude;

                // Reverse geocoding — tenta montar apenas rua, bairro e cidade
                const url = 'https://us1.locationiq.com/v1/reverse?' + new URLSearchParams({
                    key: API_KEY,
                    lat: latitude,
                    lon: longitude,
                    format: 'json'
                });

                fetch(url)
                    .then(response => {
                        if (!response.ok) {
                            throw new Error('Erro na resposta da API de localização.');
                        }
                        return response.json();
                    })
                    .then(data => {
                        if (!data || !data.address) {
                            localInput.placeholder = 'Digite o local manualmente';
                            return;
                        }

                        const addr   = data.address;
                        const rua    = addr.road || addr.pedestrian || addr.residential || addr.footway || addr.path || '';
                        const bairro = addr.suburb || addr.neighbourhood || addr.city_district || addr.quarter || '';
                        const cidade = addr.city || addr.town || addr.village || addr.county || '';

                        const finalStr = [rua, bairro, cidade]
                            .filter(p => p && p.trim() !== '')
                            .join(', ');

                        if (finalStr.length > 0) {
                            localInput.value = finalStr;
                        } else if (data.display_name) {
                            // fallback: usa display_name, podendo ser editado pelo usuário
                            localInput.value = data.display_name;
                        } else {
                            localInput.placeholder = 'Digite o local manualmente';
                        }
                    })
                    .catch(() => {
                        localInput.placeholder = 'Digite o local manualmente';
                    });
            }

            function onError() {
                localInput.placeholder = 'Digite o local manualmente';
            }
        });
    </script>
</head>
<body>
    <?php include '../includes/header.php'; ?>

    <main class="form-container">
        <h2>Cadastrar Objeto</h2>
        <p class="descricao-form">
            Preencha as informações para registrar um objeto achado ou perdido.
        </p>

        <form
            action="../php/processar_objeto.php"
            method="POST"
            enctype="multipart/form-data"
            autocomplete="on"
        >
            <label for="tipo_objeto">Tipo:</label>
            <select name="tipo_objeto" id="tipo_objeto" required>
                <option value="achado">Achado</option>
                <option value="perdido">Perdido</option>
            </select>

            <label for="titulo">Título:</label>
            <input
                type="text"
                name="titulo"
                id="titulo"
                placeholder="Ex: Carteira preta"
                required
                minlength="3"
                maxlength="100"
            >

            <label for="descricao">Descrição:</label>
            <textarea
                name="descricao"
                id="descricao"
                placeholder="Descreva o objeto..."
                required
                minlength="5"
                maxlength="1000"
            ></textarea>

            <label for="categoria">Categoria:</label>
            <input
                type="text"
                name="categoria"
                id="categoria"
                placeholder="Ex: Documentos, Eletrônicos"
                required
                maxlength="50"
            >

            <label for="local_encontrado">Local onde foi encontrado:</label>
            <input
                type="text"
                name="local_encontrado"
                id="local_encontrado"
                placeholder="Carregando localização..."
                required
                maxlength="255"
            >

            <label for="data_encontrado">Data:</label>
            <input
                type="date"
                name="data_encontrado"
                id="data_encontrado"
                required
            >

            <label for="imagem">Imagem:</label>
            <input
                type="file"
                name="imagem"
                id="imagem"
                accept="image/*"
            >

            <!-- Campos ocultos para latitude e longitude -->
            <input type="hidden" name="latitude"  id="latitude">
            <input type="hidden" name="longitude" id="longitude">

            <button type="submit" class="btn-cadastrar">
                Cadastrar Objeto
            </button>
        </form>

        <div class="info-chat">
            <p>
                🔹 Após cadastrar, outras pessoas poderão entrar em contato com você
                através do chat seguro do FindMe.
            </p>
        </div>
    </main>

    <?php include '../includes/footer.php'; ?>
</body>
</html>
