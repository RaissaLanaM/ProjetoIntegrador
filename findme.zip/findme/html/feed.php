<?php
// /html/feed.php (ou nome equivalente)
session_start();

if (!isset($_SESSION['usuario_id'])) {
    header('Location: login.php');
    exit();
}

require_once '../includes/conexao.php';

/**
 * Lista de objetos com filtro simples por categoria.
 * Usa PDO e join com tabela de usuários.
 */

$usuarioLogado = (int) $_SESSION['usuario_id'];

// Filtro de categoria (via GET)
$categoriaFiltro = isset($_GET['categoria']) ? trim($_GET['categoria']) : '';
$categoriaFiltro = mb_strtolower($categoriaFiltro, 'UTF-8');

// Monta SQL com filtro opcional
$sql = "
    SELECT 
        o.id, 
        o.titulo, 
        o.descricao, 
        o.categoria, 
        o.data_encontrado, 
        o.local_encontrado, 
        u.nome AS nome_usuario
    FROM objetos o
    JOIN usuarios u ON o.id_usuario = u.id
    WHERE (:categoria = '' OR LOWER(o.categoria) = :categoria)
    ORDER BY o.data_encontrado DESC, o.id DESC
";

$stmt = $conexao->prepare($sql);
$stmt->bindValue(':categoria', $categoriaFiltro, PDO::PARAM_STR);
$stmt->execute();
$objetos = $stmt->fetchAll(PDO::FETCH_ASSOC);

function e($s) {
    return htmlspecialchars((string) $s, ENT_QUOTES, 'UTF-8');
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Objetos Encontrados - FindMe</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Fonte e CSS -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/header.css">
    <link rel="stylesheet" href="../assets/css/dashboard.css">
    <style>
        /* Ajustes simples caso não tenha um CSS próprio para essa tela */
        .page-container {
            max-width: 980px;
            margin: 20px auto 40px;
            padding: 0 16px;
            font-family: 'Poppins', sans-serif;
        }
        .page-title {
            font-size: 1.6rem;
            margin-bottom: 0.4rem;
        }
        .page-subtitle {
            color: #6b7a90;
            margin-bottom: 1.2rem;
        }
        .filtro-form {
            display: flex;
            flex-wrap: wrap;
            gap: 8px;
            align-items: center;
            margin-bottom: 1.2rem;
        }
        .filtro-form label {
            font-weight: 500;
        }
        .filtro-form select {
            padding: 6px 10px;
            border-radius: 6px;
            border: 1px solid #c9d3e0;
        }
        .filtro-form button {
            padding: 7px 14px;
            border-radius: 6px;
            border: none;
            background: #4A7CFF;
            color: #fff;
            font-weight: 500;
            cursor: pointer;
        }
        .filtro-form button:hover {
            background: #3a64d9;
        }
        .feed-lista .card {
            background: #fff;
            border-radius: 12px;
            padding: 16px 18px;
            margin-bottom: 14px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.05);
        }
        .feed-lista .card h3 {
            margin: 0 0 6px;
            font-size: 1.1rem;
        }
        .feed-lista .card p {
            margin: 3px 0;
            font-size: 0.94rem;
            color: #334155;
        }
        .feed-lista .card a {
            display: inline-block;
            margin-top: 8px;
            font-size: 0.9rem;
            color: #4A7CFF;
            font-weight: 500;
        }
        .feed-vazio {
            margin-top: 12px;
            color: #6b7a90;
        }
    </style>
</head>
<body>

<?php include_once '../includes/header.php'; ?>

<main class="page-container">
    <h2 class="page-title">Objetos Encontrados</h2>
    <p class="page-subtitle">
        Veja os itens cadastrados pela comunidade. Use o filtro para refinar por categoria.
    </p>

    <!-- Filtros -->
    <form method="GET" action="" class="filtro-form">
        <label for="categoria">Categoria:</label>
        <select name="categoria" id="categoria">
            <option value="" <?= $categoriaFiltro === '' ? 'selected' : ''; ?>>Todas</option>
            <option value="documento"  <?= $categoriaFiltro === 'documento'  ? 'selected' : ''; ?>>Documento</option>
            <option value="eletrônico" <?= $categoriaFiltro === 'eletrônico' ? 'selected' : ''; ?>>Eletrônico</option>
            <option value="vestuário"  <?= $categoriaFiltro === 'vestuário'  ? 'selected' : ''; ?>>Vestuário</option>
            <option value="outros"     <?= $categoriaFiltro === 'outros'     ? 'selected' : ''; ?>>Outros</option>
        </select>
        <button type="submit">Filtrar</button>
    </form>

    <!-- Lista de objetos -->
    <div class="feed-lista">
        <?php if ($objetos): ?>
            <?php foreach ($objetos as $obj): ?>
                <div class="card">
                    <h3><?= e($obj['titulo']); ?></h3>

                    <p>
                        <strong>Descrição:</strong>
                        <?= e($obj['descricao']); ?>
                    </p>

                    <p>
                        <strong>Categoria:</strong>
                        <?= e($obj['categoria']); ?>
                    </p>

                    <p>
                        <strong>Encontrado em:</strong>
                        <?= e($obj['local_encontrado']); ?>
                        em
                        <?= e(date('d/m/Y', strtotime($obj['data_encontrado']))); ?>
                    </p>

                    <p>
                        <strong>Postado por:</strong>
                        <?= e($obj['nome_usuario']); ?>
                    </p>

                    <a href="detalhes_objeto.php?id=<?= (int) $obj['id']; ?>">
                        Ver detalhes
                    </a>
                </div>
            <?php endforeach; ?>
        <?php else: ?>
            <p class="feed-vazio">
                Nenhum objeto encontrado para a categoria selecionada.
            </p>
        <?php endif; ?>
    </div>
</main>

<?php include_once '../includes/footer.php'; ?>
</body>
</html>
