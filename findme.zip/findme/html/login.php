<?php
session_start();
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Login - FindMe</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Fonte -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;700&display=swap" rel="stylesheet">

    <!-- CSS -->
    <link rel="stylesheet" href="../assets/css/login.css">
</head>
<body>
    <div class="main-content">
        <div class="login-container">
            <!-- Logo ou título -->
             <div class="auth-logo">
                <img src="../assets/imagens/logo-findme2.png" alt="FindMe" />
            </div>
            <h1>FindMe</h1>
            
            <p class="subtitulo">Faça login para acessar o sistema de Achados e Perdidos</p>

            <!-- Mensagem de sucesso (cadastro) -->
            <?php if (isset($_SESSION['mensagem_sucesso'])): ?>
                <div class="msg-sucesso">
                    <?php 
                        echo $_SESSION['mensagem_sucesso'];
                        unset($_SESSION['mensagem_sucesso']);
                    ?>
                </div>
            <?php endif; ?>

            <!-- Mensagem de erro (login) -->
            <?php if (isset($_SESSION['mensagem_erro'])): ?>
                <div class="msg-erro">
                    <?php 
                        echo $_SESSION['mensagem_erro'];
                        unset($_SESSION['mensagem_erro']);
                    ?>
                </div>
            <?php endif; ?>

            <!-- Formulário de login -->
            <form action="../php/processar_login.php" method="POST" class="login-form">
                <div class="form-group">
                    <label for="email">E-mail</label>
                    <input type="email" name="email" id="email" placeholder="Digite seu e-mail" required>
                </div>

                <div class="form-group">
                    <label for="senha">Senha</label>
                    <input type="password" name="senha" id="senha" placeholder="Digite sua senha" required>
                </div>

                <button type="submit" class="btn-login">Entrar</button>
            </form>

            <!-- Links extras -->
            <div class="links-extra">
                <p class="cadastro-link">
                    Não tem uma conta? <a href="cadastro.php">Cadastre-se aqui</a>
                </p>
                <p class="reset-link">
                    <a href="recuperar_senha.php">Esqueci minha senha</a>
                </p>
            </div>
        </div>
    </div>

    <?php include_once('../includes/footer.php'); ?>
</body>
</html>
