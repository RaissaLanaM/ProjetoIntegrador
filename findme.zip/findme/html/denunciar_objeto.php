<?php
session_start();
require_once '../includes/conexao.php';

/**
 * Tela de denúncia de anúncio.
 * 
 * Regras principais:
 * - Apenas usuários logados podem denunciar;
 * - O ID do objeto é recebido via GET (parâmetro "obj");
 * - Usuário não pode denunciar o próprio objeto;
 * - Gera token CSRF específico para o formulário de denúncia.
 */

// Verifica se o usuário está logado
if (!isset($_SESSION['usuario_id'])) {
    header('Location: login.php');
    exit();
}

$usuarioLogado = (int) $_SESSION['usuario_id'];

// ID do objeto pela URL
if (!isset($_GET['obj']) || !ctype_digit($_GET['obj'])) {
    $_SESSION['mensagem_erro'] = 'Objeto inválido para denúncia.';
    header('Location: dashboard.php');
    exit();
}

$objeto_id = (int) $_GET['obj'];

// Busca dados básicos do objeto (pra mostrar um resumo no form)
$sql = "
    SELECT 
        o.id,
        o.id_usuario,
        o.titulo,
        o.local_encontrado,
        o.tipo_objeto,
        u.nome AS nome_usuario
    FROM objetos o
    JOIN usuarios u ON u.id = o.id_usuario
    WHERE o.id = :id
    LIMIT 1
";

$stmt = $conexao->prepare($sql);
$stmt->bindValue(':id', $objeto_id, PDO::PARAM_INT);
$stmt->execute();
$obj = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$obj) {
    $_SESSION['mensagem_erro'] = 'Objeto não encontrado para denúncia.';
    header('Location: dashboard.php');
    exit();
}

// Não permite denunciar o próprio objeto (regra de segurança básica)
if ((int) $obj['id_usuario'] === $usuarioLogado) {
    $_SESSION['mensagem_erro'] = 'Você não pode denunciar um objeto que você mesmo cadastrou.';
    header('Location: dashboard.php');
    exit();
}

// Token CSRF simples para o formulário de denúncia
if (empty($_SESSION['csrf_denuncia'])) {
    $_SESSION['csrf_denuncia'] = bin2hex(random_bytes(16));
}
$csrf = $_SESSION['csrf_denuncia'];

/**
 * Helper para escapar HTML com segurança.
 */
function e($s) {
    return htmlspecialchars((string) $s, ENT_QUOTES, 'UTF-8');
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Denunciar anúncio - FindMe</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Fonte e CSS -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/header.css">
    <link rel="stylesheet" href="../assets/css/denunciar.css">
</head>
<body class="fm-body-denuncia">

<?php include '../includes/header.php'; ?>

<main class="denuncia-container">
    <section class="denuncia-card" aria-labelledby="titulo-denuncia">
        <h1 id="titulo-denuncia">Denunciar anúncio</h1>
        <p class="denuncia-intro">
            Este formulário é exclusivo para reportar anúncios suspeitos ou inapropriados.
            Use com responsabilidade.
        </p>

        <div class="denuncia-resumo">
            <p><strong>Objeto:</strong> <?= e($obj['titulo']); ?></p>
            <p><strong>Tipo:</strong> <?= e(ucfirst($obj['tipo_objeto'])); ?></p>
            <p><strong>Local informado:</strong> <?= e($obj['local_encontrado']); ?></p>
            <p><strong>Anunciante:</strong> <?= e($obj['nome_usuario']); ?></p>
        </div>

        <?php if (!empty($_SESSION['mensagem_erro'])): ?>
            <div class="denuncia-msg erro" role="alert" aria-live="assertive">
                <?= e($_SESSION['mensagem_erro']); ?>
            </div>
            <?php unset($_SESSION['mensagem_erro']); ?>
        <?php endif; ?>

        <form
            class="denuncia-form"
            action="../php/denunciar_objeto.php"
            method="post"
        >
            <input type="hidden" name="csrf"      value="<?= e($csrf); ?>">
            <input type="hidden" name="objeto_id" value="<?= (int) $objeto_id; ?>">

            <label for="motivo_base">Motivo principal da denúncia</label>
            <select id="motivo_base" name="motivo_base" required>
                <option value="" disabled selected>Selecione uma opção</option>
                <option value="Golpe ou fraude">Golpe ou tentativa de fraude</option>
                <option value="Informação falsa">Informações falsas ou enganosas</option>
                <option value="Conteúdo sensível">Conteúdo impróprio / sensível</option>
                <option value="Anúncio duplicado">Anúncio duplicado / repetido</option>
                <option value="Linguagem ofensiva">Linguagem ofensiva ou abusiva</option>
                <option value="Outro">Outro motivo</option>
            </select>

            <label for="detalhes">Descreva o que está acontecendo</label>
            <textarea
                id="detalhes"
                name="detalhes"
                rows="4"
                required
                placeholder="Explique, em poucas linhas, por que você está denunciando este anúncio (ex.: combinação suspeita, pedido de dinheiro adiantado, dados estranhos, etc.)."
            ></textarea>

            <p class="denuncia-aviso">
                ⚠️ Denúncias falsas podem prejudicar usuários legítimos.
                Use somente se você realmente identificar um problema.
            </p>

            <div class="denuncia-acoes">
                <a class="btn-secundario" href="dashboard.php">Cancelar</a>
                <button class="btn-primario" type="submit">
                    Enviar denúncia
                </button>
            </div>
        </form>
    </section>
</main>

<?php include '../includes/footer.php'; ?>
</body>
</html>
