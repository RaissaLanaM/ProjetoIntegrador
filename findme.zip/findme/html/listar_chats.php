<?php
session_start();
require_once '../includes/conexao.php';

/**
 * Lista de conversas (chats) do usuário logado.
 */

// Verifica se o usuário está logado
if (!isset($_SESSION['usuario_id'])) {
    header('Location: login.php');
    exit();
}

$usuario_id = (int) $_SESSION['usuario_id'];

/*
   Pega a última mensagem de cada chat e mostra as conversas do usuário.
   - nome_outro: nome do outro participante;
   - ultima_msg: texto da última mensagem;
   - ultima_data: data/hora da última mensagem.
*/
$sql = "
    SELECT
        c.id AS chat_id,
        CASE
            WHEN c.usuario1_id = :uid1 THEN u2.nome
            ELSE u1.nome
        END AS nome_outro,
        m.mensagem AS ultima_msg,
        m.data_envio AS ultima_data
    FROM chats c
    JOIN usuarios u1 ON u1.id = c.usuario1_id
    JOIN usuarios u2 ON u2.id = c.usuario2_id
    JOIN (
        SELECT mm.chat_id, mm.mensagem, mm.data_envio
        FROM mensagens mm
        INNER JOIN (
            SELECT chat_id, MAX(data_envio) AS ultima_data
            FROM mensagens
            GROUP BY chat_id
        ) ult ON ult.chat_id = mm.chat_id AND ult.ultima_data = mm.data_envio
    ) m ON m.chat_id = c.id
    WHERE c.usuario1_id = :uid2 OR c.usuario2_id = :uid3
    ORDER BY m.data_envio DESC
";

$stmt = $conexao->prepare($sql);
$stmt->bindValue(':uid1', $usuario_id, PDO::PARAM_INT);
$stmt->bindValue(':uid2', $usuario_id, PDO::PARAM_INT);
$stmt->bindValue(':uid3', $usuario_id, PDO::PARAM_INT);
$stmt->execute();
$chats = $stmt->fetchAll(PDO::FETCH_ASSOC);

/**
 * Helper para escapar texto com segurança.
 */
function e($s) {
    return htmlspecialchars((string) $s, ENT_QUOTES, 'UTF-8');
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="utf-8">
  <title>Mensagens — FindMe</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="description" content="Veja suas conversas recentes no chat seguro do FindMe.">

  <!-- Fonte e CSS -->
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;700&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="../assets/css/header.css">
  <link rel="stylesheet" href="../assets/css/listar_chats.css">
</head>
<body class="fm-body fm-has-sticky-header">
<?php include '../includes/header.php'; ?>

<main class="fm-listar-container">
  <div class="fm-listar-top">
    <h1>Mensagens</h1>
    <p class="fm-subtitle">Suas conversas recentes</p>
  </div>

  <?php if ($chats): ?>
    <ul class="fm-chat-list">
      <?php foreach ($chats as $chat): ?>
        <?php
          $nomeOutro   = (string) ($chat['nome_outro'] ?? '');
          $ultimaMsg   = (string) ($chat['ultima_msg'] ?? '');
          $ultimaData  = $chat['ultima_data'] ?? null;
          $dataFormat  = $ultimaData ? date('d/m H:i', strtotime($ultimaData)) : '';
          $previewText = mb_strimwidth($ultimaMsg, 0, 70, '…', 'UTF-8');
        ?>
        <li class="fm-chat-item">
          <a
            class="fm-chat-card"
            href="chat.php?id=<?= (int) $chat['chat_id']; ?>"
            aria-label="Abrir conversa com <?= e($nomeOutro); ?>"
          >
            <!-- Avatar -->
            <div class="fm-avatar" aria-hidden="true">
              <span><?= strtoupper(mb_substr($nomeOutro, 0, 1, 'UTF-8')); ?></span>
            </div>

            <!-- Informações -->
            <div class="fm-chat-info">
              <div class="fm-line-1">
                <span class="fm-name"><?= e($nomeOutro); ?></span>
                <?php if ($dataFormat): ?>
                  <time class="fm-time" datetime="<?= e($ultimaData); ?>">
                    <?= e($dataFormat); ?>
                  </time>
                <?php endif; ?>
              </div>
              <div class="fm-line-2">
                <span class="fm-preview">
                  <?= e($previewText); ?>
                </span>
              </div>
            </div>

            <!-- Botão abrir (decorativo) -->
            <button class="fm-open" type="button" aria-hidden="true">Abrir</button>
          </a>
        </li>
      <?php endforeach; ?>
    </ul>
  <?php else: ?>
    <div class="fm-empty">
      <p>Você ainda não tem conversas. Envie uma mensagem a partir de um anúncio.</p>
    </div>
  <?php endif; ?>
</main>

<?php include '../includes/footer.php'; ?>
</body>
</html>
