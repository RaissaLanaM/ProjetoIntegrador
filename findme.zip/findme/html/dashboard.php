<?php
session_start();
require_once '../includes/conexao.php';

/**
 * Dashboard / feed de objetos cadastrados.
 */

// Verifica se o usuário está logado
if (!isset($_SESSION['usuario_id'])) {
    header('Location: login.php');
    exit();
}
$usuarioLogado = (int) $_SESSION['usuario_id'];

/*
  Busca objetos + dono + agregados de denúncias (quantidade e “risco”).
*/
$sql = "
  SELECT
    o.*,
    u.nome AS nome_usuario,
    COALESCE(d.denuncias, 0) AS denuncias,
    COALESCE(d.risco, 0)     AS risco
  FROM objetos o
  JOIN usuarios u ON u.id = o.id_usuario
  LEFT JOIN (
      SELECT
        objeto_id,
        COUNT(*) AS denuncias,
        SUM(
          CASE
            WHEN motivo LIKE 'Golpe ou fraude%' THEN 3
            WHEN motivo LIKE 'Informação falsa%' THEN 2
            WHEN motivo LIKE 'Conteúdo sensível%' THEN 2
            WHEN motivo LIKE 'Anúncio duplicado%' THEN 1
            WHEN motivo LIKE 'Linguagem ofensiva%' THEN 1
            ELSE 1
          END
        ) AS risco
      FROM denuncias
      GROUP BY objeto_id
  ) d ON d.objeto_id = o.id
  ORDER BY o.data_encontrado DESC, o.id DESC
";
$stmt = $conexao->prepare($sql);
$stmt->execute();
$objeto_list = $stmt->fetchAll(PDO::FETCH_ASSOC);

/* CSRF simples p/ exclusão */
if (empty($_SESSION['csrf'])) {
    $_SESSION['csrf'] = bin2hex(random_bytes(16));
}
$csrf = $_SESSION['csrf'];

/* helper para escapar HTML */
function e($s) {
    return htmlspecialchars((string) $s, ENT_QUOTES, 'UTF-8');
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Objetos cadastrados - FindMe</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Fonte e CSS -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/header.css">
    <link rel="stylesheet" href="../assets/css/dash.css?v=5">

</head>
<body>

<?php include '../includes/header.php'; ?>

<main class="dashboard-container">
    <img src="../assets/imagens/logo-findme2.png" alt="FindMe">
    <h2 class="titulo-feed">Objetos cadastrados recentemente</h2>
    <p class="subtitulo-feed">
        Itens perdidos, encontrados ou já devolvidos pela comunidade FindMe.
    </p>

    <?php if (!empty($_SESSION['mensagem_sucesso'])): ?>
        <div class="msg-sucesso" role="status" aria-live="polite">
            <?= e($_SESSION['mensagem_sucesso']); ?>
        </div>
        <?php unset($_SESSION['mensagem_sucesso']); ?>
    <?php endif; ?>

    <?php if (!empty($_SESSION['mensagem_erro'])): ?>
        <div class="msg-erro" role="alert" aria-live="assertive">
            <?= e($_SESSION['mensagem_erro']); ?>
        </div>
        <?php unset($_SESSION['mensagem_erro']); ?>
    <?php endif; ?>

    <div class="feed" aria-label="Lista de objetos encontrados ou perdidos">
        <?php if ($objeto_list): ?>
            <?php foreach ($objeto_list as $obj): ?>
                <?php
                    $isOwner     = ((int) $obj['id_usuario'] === $usuarioLogado);
                    $tipo        = (string) ($obj['tipo_objeto'] ?? '');
                    $textoStatus = ucfirst($tipo);
                    $badgeClass  = ($tipo === 'perdido')
                        ? 'status-perdido'
                        : (($tipo === 'devolvido') ? 'status-devolvido' : 'status-achado');

                    $imgName   = trim((string) ($obj['imagem'] ?? ''));
                    $imgWeb    = $imgName ? "../uploads/objetos/{$imgName}" : '';
                    $imgFsPath = $imgName ? realpath(__DIR__ . "/../uploads/objetos/{$imgName}") : false;
                    $temArquivo = ($imgName && $imgFsPath && is_file($imgFsPath));

                    $denuncias = (int) ($obj['denuncias'] ?? 0);
                    $risco     = (int) ($obj['risco'] ?? 0);

                    // 0-2: sem aviso | 3-5: aviso amarelo | 6+: aviso vermelho (sério)
                    $alertLevel = 0;
                    if ($denuncias >= 3 && $denuncias <= 5) {
                        $alertLevel = 1;
                    }
                    if ($denuncias >= 6) {
                        $alertLevel = 2;
                    }
                ?>

                <article
                    class="card-objeto <?= $alertLevel === 2 ? 'flagged-hard' : ''; ?>"
                    aria-label="Objeto cadastrado"
                >
                    <div class="card-top">
                        <span class="status <?= e($badgeClass); ?>">
                            <?= e($textoStatus); ?>
                        </span>

                        <?php if ($alertLevel > 0): ?>
                            <div
                                class="alert-report <?= $alertLevel === 2 ? 'danger' : 'warning'; ?>"
                                role="alert"
                            >
                                <?php if ($alertLevel === 1): ?>
                                    ⚠️ Este anúncio recebeu
                                    <strong><?= $denuncias; ?></strong> denúncias
                                    (risco <?= $risco; ?>).
                                    Cuidado e verifique as informações antes de prosseguir.
                                <?php else: ?>
                                    🚫 Este anúncio recebeu
                                    <strong><?= $denuncias; ?></strong> denúncias
                                    (risco <?= $risco; ?>).
                                    Recomendamos <strong>não prosseguir</strong> com contato/entrega.
                                <?php endif; ?>
                            </div>
                        <?php endif; ?>

                        <div class="objeto-img-wrapper">
                            <?php if ($temArquivo): ?>
                                <img
                                    src="<?= e($imgWeb); ?>"
                                    alt="Imagem do objeto: <?= e($obj['titulo']); ?>"
                                    class="objeto-img"
                                    loading="lazy"
                                >
                            <?php else: ?>
                                <div
                                    class="objeto-img placeholder"
                                    role="img"
                                    aria-label="Sem imagem disponível para este objeto"
                                >
                                    <span>Sem imagem enviada para este anúncio.</span>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="card-body">
                        <h3 class="objeto-titulo">
                            <?= e($obj['titulo']); ?>
                        </h3>

                        <p class="objeto-descricao">
                            <?= nl2br(e($obj['descricao'])); ?>
                        </p>

                        <p class="objeto-info">
                            <strong>Categoria:</strong> <?= e($obj['categoria']); ?>
                        </p>
                        <p class="objeto-info">
                            <strong>Local:</strong> <?= e($obj['local_encontrado']); ?>
                        </p>
                        <p class="objeto-info">
                            <strong>Data:</strong>
                            <?= e(date('d/m/Y', strtotime($obj['data_encontrado']))); ?>
                        </p>

                        <p class="objeto-info usuario-cadastrou">
                            <strong>Cadastrado por:</strong> <?= e($obj['nome_usuario']); ?>
                        </p>

                        <div class="card-acao">
                            <?php if ($isOwner): ?>
                                <div class="acoes-proprio">
                                    <a
                                        class="btn-editar"
                                        href="../html/editar_objeto.php?id=<?= (int) $obj['id']; ?>"
                                        title="Editar objeto"
                                        rel="noopener"
                                    >
                                        <svg viewBox="0 0 24 24" aria-hidden="true">
                                            <path
                                                fill="currentColor"
                                                d="M3 17.25V21h3.75L17.81 9.94l-3.75-3.75L3 17.25Zm14.71-9.04c.39-.39.39-1.02 0-1.41l-2.5-2.5a.9959.9959 0 0 0-1.41 0l-1.83 1.83 3.75 3.75 1.99-1.67Z"
                                            />
                                        </svg>
                                        Editar
                                    </a>

                                    <form
                                        class="form-excluir"
                                        action="../php/excluir_objeto.php"
                                        method="POST"
                                    >
                                        <input type="hidden" name="csrf" value="<?= e($csrf); ?>">
                                        <input type="hidden" name="id"   value="<?= (int) $obj['id']; ?>">

                                        <button
                                            class="btn-excluir"
                                            type="submit"
                                            title="Excluir objeto"
                                        >
                                            <svg viewBox="0 0 24 24" aria-hidden="true">
                                                <path
                                                    fill="currentColor"
                                                    d="M9 3h6a1 1 0 0 1 1 1v1h4v2H4V5h4V4a1 1 0 0 1 1-1Zm1 7h2v8h-2v-8Zm4 0h2v8h-2v-8ZM6 7h12v12a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2V7Z"
                                                />
                                            </svg>
                                            Excluir
                                        </button>
                                    </form>
                                </div>
                            <?php else: ?>
                                <a
                                    class="btn-chat"
                                    href="../php/iniciar_chat.php?id_dono=<?= (int) $obj['id_usuario']; ?>"
                                    rel="noopener"
                                >
                                    <span class="chat-icone" aria-hidden="true">💬</span>
                                    <span>Conversar com o dono</span>
                                </a>

                                <a
                                    class="btn-denunciar"
                                    href="../html/denunciar_objeto.php?obj=<?= (int) $obj['id']; ?>"
                                    rel="noopener"
                                >
                                    <svg viewBox="0 0 24 24" aria-hidden="true">
                                        <path
                                            fill="currentColor"
                                            d="M4 3h14l-1.5 4L18 11H6l-2-6V3Zm2 14h10v2H6v-2Z"
                                        />
                                    </svg>
                                    Denunciar
                                </a>
                            <?php endif; ?>
                        </div>
                    </div>
                </article>
            <?php endforeach; ?>
        <?php else: ?>
            <p class="nenhum-objeto">
                Nenhum objeto cadastrado ainda.
            </p>
        <?php endif; ?>
    </div>
</main>

<?php include '../includes/footer.php'; ?>

<script>
'use strict';

// Confirmação de exclusão de objeto
document.querySelectorAll('.form-excluir').forEach(function (form) {
  form.addEventListener('submit', function (e) {
    const ok = confirm(
      'Tem certeza que deseja excluir este objeto? Esta ação não pode ser desfeita.'
    );
    if (!ok) {
      e.preventDefault();
    }
  });
});
</script>

</body>
</html>
